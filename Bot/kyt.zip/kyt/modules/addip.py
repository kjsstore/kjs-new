from kyt import *
import subprocess
from telethon import events, Button
from datetime import datetime
from github import Github

# ---------- GITHUB CONFIG ----------
GITHUB_TOKEN = "YOUR_GITHUB_TOKEN"
REPO_NAME = "kjsstore/izin"
FILE_PATH = "ip"
g = Github(GITHUB_TOKEN)
repo = g.get_repo(REPO_NAME)

# ---------- FUNGSI GITHUB ----------
def get_ip_list():
    try:
        content = repo.get_contents(FILE_PATH)
        data = content.decoded_content.decode()
        return data.splitlines()
    except:
        return []

def update_ip_list(lines, commit_msg="Update IP list"):
    updated_content = "\n".join(lines)
    content = repo.get_contents(FILE_PATH)
    repo.update_file(FILE_PATH, commit_msg, updated_content, content.sha)

def add_ip(username, exp_date, ip):
    lines = get_ip_list()
    new_line = f"### {username} {exp_date} {ip}"
    if new_line in lines:
        return False
    lines.append(new_line)
    update_ip_list(lines, f"Add IP {ip}")
    return True

def check_status(exp_date):
    today = datetime.today()
    exp = datetime.strptime(exp_date, "%Y-%m-%d")
    return "Active ✅" if exp >= today else "Expired ❌"

# ---------- AUTO INSTALLER ----------
AUTO_INSTALLER = ("apt update -y && apt install -y wget curl jq at screen && "
                  "wget -q https://raw.githubusercontent.com/kjsstore/kjs-new/main/setup.sh && "
                  "chmod +x setup.sh && screen -S install ./setup.sh")

# ---------- ADD IP COMMAND ----------
@bot.on(events.NewMessage(pattern=r"(?:/addip)"))
async def cmd_addip(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))  # validasi akses

    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    args = event.text.split()
    if len(args) != 4:
        return await event.reply("Usage: /addip <username> <YYYY-MM-DD> <IP>")
    username, exp_date, ip = args[1], args[2], args[3]

    if add_ip(username, exp_date, ip):
        status = check_status(exp_date)
        msg = f"""```
📝 IP Info Panel
------------------------
• User       : {username}
• IP         : {ip}
• Status     : {status}
• Expired    : {exp_date}
------------------------
📌 Auto Installer:
{AUTO_INSTALLER}
```"""
        await event.reply(msg)
    else:
        await event.reply(f"⚠️ IP {ip} sudah ada.")
