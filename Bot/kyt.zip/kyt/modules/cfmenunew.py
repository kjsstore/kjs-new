# ============================================================
# ⚙️ CLOUDFLARE POINTING FULL BUTTON + HISTORY
# ============================================================
from kyt import *
import subprocess
from telethon import events, Button
import requests, json, re

from globalsub import global_subdomain

# ---------- GLOBAL SESSION ----------
user_pointing_session = {}   # Sementara untuk wizard IP/Domain
user_pointing_history = {}   # Menyimpan history tiap user


# ---------- POINTING MENU ----------
@bot.on(events.CallbackQuery(pattern=b'pointing-menu'))
async def cb_pointing_menu(event):
    buttons = [
        [Button.inline("🆕 Create / Update Pointing", b'create-update')],
        [Button.inline("❌ Delete Pointing", b'del-pointing')],
        [Button.inline("📄 List Pointing", b'list-pointing')],
        [Button.inline("🕘 History Pointing", b'history-pointing')],
        [Button.inline("⬅️ Kembali ke Cloudflare Menu", b'cfmenu')],
    ]
    msg = "📡 *CLOUDFLARE POINTING MENU*\n────────────────────────────\nPilih aksi yang ingin dilakukan:"
    await event.edit(msg, buttons=buttons)


# ---------- LIST POINTING ----------
@bot.on(events.CallbackQuery(pattern=b'list-pointing'))
async def cb_list_pointing(event):
    msg = "📄 *Daftar Domain/Subdomain Pointing*\n────────────────────────────\n"
    for domain, data in global_subdomain.items():
        zone = data["zone"]
        apitoken = data["apitoken"]
        headers = {"Authorization": f"Bearer {apitoken}", "Content-Type": "application/json"}

        try:
            a_url = f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records?type=A&name={domain}"
            res = requests.get(a_url, headers=headers).json()
            ip = res["result"][0]["content"] if res.get("result") else "Belum di-pointing"
        except:
            ip = "Gagal ambil data"

        msg += f"🌐 {domain} → {ip}\n"
    msg += "────────────────────────────"
    await event.edit(msg)


# ---------- HISTORY POINTING ----------
@bot.on(events.CallbackQuery(pattern=b'history-pointing'))
async def cb_history_pointing(event):
    user_id = event.sender_id
    history = user_pointing_history.get(user_id, [])
    if not history:
        return await event.edit("⚠️ Tidak ada history pointing!")

    buttons = []
    for idx, h in enumerate(history[-10:][::-1], 1):  # Tampilkan 10 terakhir
        buttons.append([Button.inline(f"{h['ip']} → {h['domain']}", f"history-{idx}")])
    buttons.append([Button.inline("⬅️ Kembali ke Menu Pointing", b'pointing-menu')])
    await event.edit("🕘 *History Pointing Terakhir*:", buttons=buttons)


# Tombol history handler
@bot.on(events.CallbackQuery(pattern=r'history-(\d+)'))
async def cb_history_select(event):
    user_id = event.sender_id
    idx = int(event.pattern_match.group(1)) - 1
    history = user_pointing_history.get(user_id, [])
    if not history or idx >= len(history):
        return await event.edit("❌ History tidak ditemukan!")

    item = history[::-1][idx]  # karena list ditampilkan reverse
    user_pointing_session[user_id] = {"ip": item["ip"]}
    await event.edit(f"✅ IP *{item['ip']}* dari history dipilih. Sekarang kirim domain/subdomain untuk pointing:")

    @bot.on(events.NewMessage(from_users=user_id))
    async def input_domain(f):
        full_domain = f.text.lower().strip()
        domain = next((d for d in global_subdomain if full_domain.endswith(d)), None)
        if not domain:
            return await f.reply(f"❌ Domain *{full_domain}* tidak terdaftar!")

        ip_addr = user_pointing_session[user_id]["ip"]
        zone = global_subdomain[domain]["zone"]
        apitoken = global_subdomain[domain]["apitoken"]
        headers = {"Authorization": f"Bearer {apitoken}", "Content-Type": "application/json"}

        # Hapus record A lama
        a_url = f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records?type=A&name={full_domain}"
        res = requests.get(a_url, headers=headers).json()
        if res.get("result") and len(res["result"]) > 0:
            for rec in res["result"]:
                requests.delete(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records/{rec['id']}", headers=headers)

        # Buat record A baru
        body = {"type": "A", "name": full_domain, "content": ip_addr, "ttl": 1, "proxied": False}
        res_create = requests.post(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records", headers=headers, data=json.dumps(body))
        res_json = res_create.json()
        if res_json.get("success"):
            # Simpan ke history
            user_pointing_history.setdefault(user_id, []).append({"ip": ip_addr, "domain": full_domain})
            await f.reply(f"✅ Record A *{full_domain}* berhasil dibuat/di-update ke IP *{ip_addr}*!")
        else:
            await f.reply(f"❌ Gagal pointing!\n{json.dumps(res_json['errors'], indent=2)}")
        bot.remove_event_handler(input_domain)
        user_pointing_session.pop(user_id, None)


# ---------- CREATE / UPDATE POINTING ----------
@bot.on(events.CallbackQuery(pattern=b'create-update'))
async def cb_create_update(event):
    user_pointing_session[event.sender_id] = {}
    await event.edit("❗ Kirim *IP Address* untuk domain/subdomain:")

    @bot.on(events.NewMessage(from_users=event.sender_id))
    async def input_ip(e):
        ip = e.text.strip()
        if not re.match(r"^(\d{1,3}\.){3}\d{1,3}$", ip):
            return await e.reply(f"⚠️ Format IP tidak valid: *{ip}*")
        user_pointing_session[event.sender_id]["ip"] = ip
        await e.reply("✅ IP diterima! Sekarang kirim *Domain/Subdomain* untuk pointing:")
        bot.remove_event_handler(input_ip)

        @bot.on(events.NewMessage(from_users=event.sender_id))
        async def input_domain(f):
            domain_input = f.text.lower().strip()
            domain = next((d for d in global_subdomain if domain_input.endswith(d)), None)
            if not domain:
                return await f.reply(f"❌ Domain *{domain_input}* tidak terdaftar!")

            ip_addr = user_pointing_session[event.sender_id]["ip"]
            zone = global_subdomain[domain]["zone"]
            apitoken = global_subdomain[domain]["apitoken"]
            headers = {"Authorization": f"Bearer {apitoken}", "Content-Type": "application/json"}

            # Hapus record A lama
            a_url = f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records?type=A&name={domain_input}"
            res = requests.get(a_url, headers=headers).json()
            if res.get("result") and len(res["result"]) > 0:
                for rec in res["result"]:
                    requests.delete(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records/{rec['id']}", headers=headers)

            # Buat record A baru
            body = {"type": "A", "name": domain_input, "content": ip_addr, "ttl": 1, "proxied": False}
            res_create = requests.post(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records", headers=headers, data=json.dumps(body))
            res_json = res_create.json()
            if res_json.get("success"):
                # Simpan ke history
                user_pointing_history.setdefault(event.sender_id, []).append({"ip": ip_addr, "domain": domain_input})
                await f.reply(f"✅ Record A *{domain_input}* berhasil dibuat/di-update ke IP *{ip_addr}*!")
            else:
                await f.reply(f"❌ Gagal pointing!\n{json.dumps(res_json['errors'], indent=2)}")
            bot.remove_event_handler(input_domain)
            user_pointing_session.pop(event.sender_id, None)


# ---------- DELETE POINTING ----------
@bot.on(events.CallbackQuery(pattern=b'del-pointing'))
async def cb_del_pointing(event):
    await event.edit("❗ Kirim domain/subdomain yang ingin dihapus record A-nya:")

    @bot.on(events.NewMessage(from_users=event.sender_id))
    async def del_input_domain(e):
        full_domain = e.text.lower().strip()
        domain = next((d for d in global_subdomain if full_domain.endswith(d)), None)
        if not domain:
            return await e.reply(f"❌ Domain *{full_domain}* tidak terdaftar!")

        zone = global_subdomain[domain]["zone"]
        apitoken = global_subdomain[domain]["apitoken"]
        headers = {"Authorization": f"Bearer {apitoken}", "Content-Type": "application/json"}

        a_url = f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records?type=A&name={full_domain}"
        res = requests.get(a_url, headers=headers).json()
        if res.get("result") and len(res["result"]) > 0:
            for rec in res["result"]:
                requests.delete(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records/{rec['id']}", headers=headers)
            await e.reply(f"✅ Record A *{full_domain}* berhasil dihapus!")
        else:
            await e.reply(f"⚠️ Record A *{full_domain}* tidak ditemukan!")
        bot.remove_event_handler(del_input_domain)
