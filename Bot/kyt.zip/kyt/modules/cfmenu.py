# ---------- CF MENU FULL CLEAN ----------
from kyt import *
import subprocess
import requests
from telethon import events, Button


@bot.on(events.NewMessage(pattern=r"(?:.cfmenu|/cfmenu)$"))
@bot.on(events.CallbackQuery(data=b'cfmenu'))
async def cfmenu(event):
    inline = [
        [Button.inline("➕ ADD CLOUDFLARE", b'addcf-menu')],
        [Button.inline("🌍 SET ZONE", b'setzone-menu'),
         Button.inline("📡 POINTING DOMAIN", b'pointing-cf')],
        [Button.inline("📋 LIST POINTING", b'listpoint-menu')],
        [Button.inline("♻️ UPDATE POINTING", b'updatepoint-menu'),
         Button.inline("❌ DELETE POINTING", b'delpoint-menu')],
        [Button.inline("ℹ️ ACCOUNT INFO", b'cfinfo-menu')],
        [Button.inline("‹ BACK MENU ›", b'menu')]]

    msg = f"""
──────╍╍╍──────
🕊️CLOUDFLARE MANAGER🕊️
──────╍╍╍──────
🤖 Admin       : @kjsstore
──────╍╍╍──────
"""
    await event.edit(msg, buttons=inline)
