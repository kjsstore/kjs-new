# ---------- CF MENU FULL CLEAN ----------
from kyt import *
import subprocess
import requests
from telethon import events, Button


@bot.on(events.NewMessage(pattern=r"(?:.cfmenu|/cfmenu)$"))
@bot.on(events.CallbackQuery(data=b'cfmenu'))
async def cfmenu(event):
    inline = [
        [Button.inline("➕ ADD CLOUDFLARE", b'addcf-menu')],
        [Button.inline("🌍 SET ZONE", b'setzone-menu'),
         Button.inline("📡 POINTING DOMAIN", b'pointing-menu')],
        [Button.inline("📋 LIST POINTING", b'listpoint-menu')],
        [Button.inline("♻️ UPDATE POINTING", b'updatepoint-menu'),
         Button.inline("❌ DELETE POINTING", b'delpoint-menu')],
        [Button.inline("ℹ️ ACCOUNT INFO", b'cfinfo-menu')],
        [Button.inline("‹ BACK MENU ›", b'menu')]
    ]

    msg = f"""```
  〔 🌐 CLOUDFLARE MANAGER 🌐 〕

Kelola domain kamu langsung dari boti.
tombol di bawah untuk mengatur.

```"""
    await event.edit(msg, buttons=inline)

# ---------- CALLBACK HANDLERS ----------
@bot.on(events.CallbackQuery(pattern=b'addcf-menu'))
async def cb_addcf(event):
    await event.edit("📥 Gunakan perintah:\n`/addcf <API_KEY> <EMAIL>`\nContoh:\n`/addcf 05cbd81c22668a6fd8c59f895c45fabd2255e email@gmail.com`")

@bot.on(events.CallbackQuery(pattern=b'setzone-menu'))
async def cb_setzone(event):
    await event.edit("🌍 Gunakan perintah:\n`/setcfzone <domain>`\nContoh:\n`/setcfzone example.com`")

@bot.on(events.CallbackQuery(pattern=b'pointing-menu'))
async def cb_pointing(event):
    await event.edit("📡 Gunakan perintah:\n`/pointing <IP> <full.domain>`\nContoh:\n`/pointing 123.45.67.89 sub.example.com`\nWildcard akan otomatis dibuat.")

@bot.on(events.CallbackQuery(pattern=b'listpoint-menu'))
async def cb_listpoint(event):
    await event.edit("📋 Gunakan perintah:\n`/listpoint`\nMenampilkan semua DNS record aktif.")

@bot.on(events.CallbackQuery(pattern=b'updatepoint-menu'))
async def cb_updatepoint(event):
    await event.edit("♻️ Gunakan perintah:\n`/updatepoint <full.domain> <IP>`\nContoh:\n`/updatepoint sub.example.com 123.45.67.89`")

@bot.on(events.CallbackQuery(pattern=b'delpoint-menu'))
async def cb_delpoint(event):
    await event.edit("❌ Gunakan perintah:\n`/delpoint <full.domain>`\nContoh:\n`/delpoint sub.example.com`")

@bot.on(events.CallbackQuery(pattern=b'cfinfo-menu'))
async def cb_cfinfo(event):
    await event.edit("ℹ️ Gunakan perintah:\n`/cfinfo`\nMelihat info akun Cloudflare aktif.")
