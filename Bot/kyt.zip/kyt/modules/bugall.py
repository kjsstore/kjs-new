# === MENU BUG ALL ===
@bot.on(events.CallbackQuery(data=b'bugall'))
async def bugall(event):
    async def bugall_(event):
        inline = [
            [Button.inline("‹ MEMBER XRAY ›", "member-bug")],
            [Button.inline(" BUG AXIS ", "bug-axis"),
             Button.inline(" BUG ISAT ", "bug-isat")],
            [Button.inline(" BUG TSEL ", "bug-tsel"),
             Button.inline(" BUG XL ", "bug-xl")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
╭━━━〔 🐾🕊️ BUG MANAGER 🕊️🐾 〕
┃
┃  🔰 **Service**     : `BUG`
┃  🌐 **Hostname/IP** : `{DOMAIN}`
┃  🏢 **ISP**         : `{z["isp"]}`
┃  🌍 **Country**     : `{z["country"]}`
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bugall_(event)
    else:
        await event.answer("Access Denied", alert=True)


# === HANDLER BUG AXIS ===
@bot.on(events.CallbackQuery(data=b'bug-axis'))
async def bug_axis(event):
    msg = f"""
╭━━━〔 🟣 BUG AXIS CONFIG 🟣 〕
┃
┃  🔰 **Service**     : `BUG AXIS`
┃  🌐 **Hostname/IP** : `{DOMAIN}`
┃
┃  📡 Gunakan config khusus AXIS.
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
    inline = [
        [Button.inline(" TRIAL XL ", "trial-xl"),
         Button.inline(" CREATE XL ", "create-xl")],
        [Button.inline(" CHECK XL ", "cek-xl"),
         Button.inline(" DELETE XL ", "delete-xl")],
        [Button.inline(" LOCK XL ", "lock-xl"),
         Button.inline(" UNLOCK XL ", "unlock-xl")],
        [Button.inline("‹ Back", "bugall")]
    ]
    await event.edit(msg, buttons=inline)


# === HANDLER BUG ISAT ===
@bot.on(events.CallbackQuery(data=b'bug-isat'))
async def bug_isat(event):
    msg = f"""
╭━━━〔 🔵 BUG INDOSAT CONFIG 🔵 〕
┃
┃  🔰 **Service**     : `BUG ISAT`
┃  🌐 **Hostname/IP** : `{DOMAIN}`
┃
┃  📡 Gunakan config khusus INDOSAT.
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
    inline = [
        [Button.inline(" TRIAL XL ", "trial-xl"),
         Button.inline(" CREATE XL ", "create-xl")],
        [Button.inline(" CHECK XL ", "cek-xl"),
         Button.inline(" DELETE XL ", "delete-xl")],
        [Button.inline(" LOCK XL ", "lock-xl"),
         Button.inline(" UNLOCK XL ", "unlock-xl")],
        [Button.inline("‹ Back", "bugall")]
    ]
    await event.edit(msg, buttons=inline)


# === HANDLER BUG TSEL ===
@bot.on(events.CallbackQuery(data=b'bug-tsel'))
async def bug_tsel(event):
    msg = f"""
╭━━━〔 🔴 BUG TELKOMSEL CONFIG 🔴 〕
┃
┃  🔰 **Service**     : `BUG TSEL`
┃  🌐 **Hostname/IP** : `{DOMAIN}`
┃
┃  📡 Gunakan config khusus TELKOMSEL.
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
    inline = [
        [Button.inline(" TRIAL XL ", "trial-xl"),
         Button.inline(" CREATE XL ", "create-xl")],
        [Button.inline(" CHECK XL ", "cek-xl"),
         Button.inline(" DELETE XL ", "delete-xl")],
        [Button.inline(" LOCK XL ", "lock-xl"),
         Button.inline(" UNLOCK XL ", "unlock-xl")],
        [Button.inline("‹ Back", "bugall")]
    ]
    await event.edit(msg, buttons=inline)


# === HANDLER BUG XL ===
@bot.on(events.CallbackQuery(data=b'bug-xl'))
async def bug_xl(event):
    msg = f"""
╭━━━〔 🟢 BUG XL CONFIG 🟢 〕
┃
┃  🔰 **Service**     : `BUG XL`
┃  🌐 **Hostname/IP** : `{DOMAIN}`
┃
┃  📡 Gunakan config khusus XL.
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
    inline = [
        [Button.inline(" TRIAL XL ", "trial-xl"),
         Button.inline(" CREATE XL ", "create-xl")],
        [Button.inline(" CHECK XL ", "cek-xl"),
         Button.inline(" DELETE XL ", "delete-xl")],
        [Button.inline(" LOCK XL ", "lock-xl"),
         Button.inline(" UNLOCK XL ", "unlock-xl")],
        [Button.inline("‹ Back", "bugall")]
    ]
    await event.edit(msg, buttons=inline)

