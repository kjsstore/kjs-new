# bugall.py
from kyt import *
import subprocess
import requests

# === MENU BUG & PAYLOAD ===
@bot.on(events.NewMessage(pattern=r"(?:.bugall|/bugall)$"))
@bot.on(events.CallbackQuery(data=b'bugall'))
async def bugall_handler(event):
    def safe_cmd(cmd):
        try:
            out = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode().strip()
            return out if out else "N/A"
        except Exception:
            return "N/A"

    namaos = safe_cmd("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").replace('"','')
    ipsaya = safe_cmd("curl -s ipv4.icanhazip.com")
    city = safe_cmd("cat /etc/xray/city")
    domain = globals().get("DOMAIN", "N/A")

    payload_count = "N/A"
    try:
        payload_count = subprocess.check_output(
            "if [ -d /etc/bugall ]; then ls -1 /etc/bugall | wc -l; "
            "elif [ -f /etc/bugall.db ]; then cat /etc/bugall.db | grep -c '###'; "
            "else echo 'N/A'; fi",
            shell=True, stderr=subprocess.DEVNULL
        ).decode().strip()
    except Exception:
        payload_count = "N/A"

    inline = [
        [Button.inline(" BUG & PAYLOD XL ","create-bugxl")],
        [Button.inline(" BUG & PAYLOD AXIS ","create-bugaxis")],
        [Button.inline(" BUG & PAYLOD ISAT ","create-bugisat"),
         Button.inline(" BUG & PAYLOD TSEL ","create-bugtsel")],
        [Button.inline(" CHECK BUG STATUS ","cek-bug"),
         Button.inline(" IMPORT BUG & PAYLOD","tarobug")],
        [Button.inline(" ‹ Back to MENU › ","menu")]
    ]

    msg = f"""
╭〔 🐛 BUG & PAYLOAD MANAGER 🐛 〕
│
│ **» OS       :** `{namaos.strip()}`
│ **» CITY     :** `{city.strip()}`
│ **» DOMAIN   :** `{domain}`
│ **» IP VPS   :** `{ipsaya.strip()}`
│
│ **📦 Total Payloads / Bug Entries :** `{payload_count}`
│
╰──────────────────────────╯
"""
    try:
        await event.edit(msg, buttons=inline)
    except Exception:
        try:
            await event.reply(msg, buttons=inline)
        except Exception:
            await event.respond(msg)


# === HANDLER TOMBOL-TOMBOL ===

@bot.on(events.CallbackQuery(data=b'bugxl1'))
async def create_bugxl(event):
    msg = "🟢 Handler BUG XL dipanggil.\n\n# TODO: tambahkan logika generate config/bug XL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'bugxl2'))
async def create_bugaxis(event):
    msg = "🟢 Handler BUG AXIS dipanggil.\n\n# TODO: tambahkan logika generate config/bug AXIS di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'bugxl3'))
async def create_bugisat(event):
    msg = "🟢 Handler BUG INDOSAT dipanggil.\n\n# TODO: tambahkan logika generate config/bug INDOSAT di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'bugxl4'))
async def create_bugtsel(event):
    msg = "🟢 Handler BUG TELKOMSEL dipanggil.\n\n# TODO: tambahkan logika generate config/bug TELKOMSEL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'bugxl5'))
async def cek_bug(event):
    msg = "🔎 Handler CEK BUG STATUS dipanggil.\n\n# TODO: tambahkan logika cek status bug/payload."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'bugxl6'))
async def import_bug(event):
    msg = "📥 Handler IMPORT BUG & PAYLOAD dipanggil.\n\n# TODO: tambahkan logika import file/database bug."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])
    
@bot.on(events.CallbackQuery(data=b'bugxl7'))
async def import_bug(event):
    msg = "📥 Handler IMPORT BUG & PAYLOAD dipanggil.\n\n# TODO: tambahkan logika import file/database bug."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])
    


# --- BUG XL ---
@bot.on(events.CallbackQuery(data=b'create-bugxl'))
async def bug_xl(event):
    async def bug_xl_():
        inline = [
            [Button.inline("‹ XL BIZ STARTER ›","bugxl1")],
            [Button.inline(" XL BIZ LITE ","bugxl2"),
             Button.inline(" XL EDUKASI ","bugxl3")],
            [Button.inline(" XL IFLIX ","bugxl4"),
             Button.inline(" XL DB YOUTUBE ","bugxl5")],
            [Button.inline(" XL UTT ","bugxl6"),
             Button.inline(" XL GRAB ","bugxl7")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "N/A")
            country = z.get("country", "N/A")
        except Exception:
            isp = "N/A"; country = "N/A"

        msg = f"""
╭━━━〔 🐾🕊️ BUG & PAYLOAD XL 🕊️🐾 〕
┃
┃  🔰 **Service**     : `BUG & PAYLOAD XL`
┃  🌐 **Hostname/IP** : `{globals().get('DOMAIN','N/A')}`
┃  🏢 **ISP**         : `{isp}`
┃  🌍 **Country**     : `{country}`
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bug_xl_()
    else:
        await event.answer("Access Denied", alert=True)
        
# === HANDLER TOMBOL-TOMBOL ===

@bot.on(events.CallbackQuery(data=b'create-bugxl'))
async def create_bugxl(event):
    msg = "🟢 Handler BUG XL dipanggil.\n\n# TODO: tambahkan logika generate config/bug XL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugaxis'))
async def create_bugaxis(event):
    msg = "🟢 Handler BUG AXIS dipanggil.\n\n# TODO: tambahkan logika generate config/bug AXIS di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugisat'))
async def create_bugisat(event):
    msg = "🟢 Handler BUG INDOSAT dipanggil.\n\n# TODO: tambahkan logika generate config/bug INDOSAT di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugtsel'))
async def create_bugtsel(event):
    msg = "🟢 Handler BUG TELKOMSEL dipanggil.\n\n# TODO: tambahkan logika generate config/bug TELKOMSEL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'cek-bug'))
async def cek_bug(event):
    msg = "🔎 Handler CEK BUG STATUS dipanggil.\n\n# TODO: tambahkan logika cek status bug/payload."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'tarobug'))
async def import_bug(event):
    msg = "📥 Handler IMPORT BUG & PAYLOAD dipanggil.\n\n# TODO: tambahkan logika import file/database bug."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])
    
          


# --- BUG AXIS ---
@bot.on(events.CallbackQuery(data=b'create-bugaxis'))
async def bug_axis(event):
    async def bug_axis_():
        inline = [
            [Button.inline("‹ MEMBER BUG AXIS ›","member-bugaxis")],
            [Button.inline(" CREATE BUG AXIS ","create-bugaxis-now"),
             Button.inline(" TRIAL BUG AXIS ","trial-bugaxis")],
            [Button.inline(" CHECK BUG AXIS ","cek-bugaxis"),
             Button.inline(" DELETE BUG AXIS ","delete-bugaxis")],
            [Button.inline(" LOCK BUG AXIS ","lock-bugaxis"),
             Button.inline(" UNLOCK BUG AXIS ","unlock-bugaxis")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "N/A")
            country = z.get("country", "N/A")
        except Exception:
            isp = "N/A"; country = "N/A"

        msg = f"""
╭━━━〔 🐾🕊️ BUG & PAYLOAD AXIS 🕊️🐾 〕
┃
┃  🔰 **Service**     : `BUG & PAYLOAD AXIS`
┃  🌐 **Hostname/IP** : `{globals().get('DOMAIN','N/A')}`
┃  🏢 **ISP**         : `{isp}`
┃  🌍 **Country**     : `{country}`
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bug_axis_()
    else:
        await event.answer("Access Denied", alert=True)
        
# === HANDLER TOMBOL-TOMBOL ===

@bot.on(events.CallbackQuery(data=b'create-bugxl'))
async def create_bugxl(event):
    msg = "🟢 Handler BUG XL dipanggil.\n\n# TODO: tambahkan logika generate config/bug XL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugaxis'))
async def create_bugaxis(event):
    msg = "🟢 Handler BUG AXIS dipanggil.\n\n# TODO: tambahkan logika generate config/bug AXIS di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugisat'))
async def create_bugisat(event):
    msg = "🟢 Handler BUG INDOSAT dipanggil.\n\n# TODO: tambahkan logika generate config/bug INDOSAT di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugtsel'))
async def create_bugtsel(event):
    msg = "🟢 Handler BUG TELKOMSEL dipanggil.\n\n# TODO: tambahkan logika generate config/bug TELKOMSEL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'cek-bug'))
async def cek_bug(event):
    msg = "🔎 Handler CEK BUG STATUS dipanggil.\n\n# TODO: tambahkan logika cek status bug/payload."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'tarobug'))
async def import_bug(event):
    msg = "📥 Handler IMPORT BUG & PAYLOAD dipanggil.\n\n# TODO: tambahkan logika import file/database bug."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])
    
        


# --- BUG INDOSAT (ISAT) ---
@bot.on(events.CallbackQuery(data=b'create-bugisat'))
async def bug_isat(event):
    async def bug_isat_():
        inline = [
            [Button.inline("‹ MEMBER BUG ISAT ›","member-bugisat")],
            [Button.inline(" CREATE BUG ISAT ","create-bugisat-now"),
             Button.inline(" TRIAL BUG ISAT ","trial-bugisat")],
            [Button.inline(" CHECK BUG ISAT ","cek-bugisat"),
             Button.inline(" DELETE BUG ISAT ","delete-bugisat")],
            [Button.inline(" LOCK BUG ISAT ","lock-bugisat"),
             Button.inline(" UNLOCK BUG ISAT ","unlock-bugisat")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "N/A")
            country = z.get("country", "N/A")
        except Exception:
            isp = "N/A"; country = "N/A"

        msg = f"""
╭━━━〔 🐾🕊️ BUG & PAYLOAD INDOSAT 🕊️🐾 〕
┃
┃  🔰 **Service**     : `BUG & PAYLOAD INDOSAT`
┃  🌐 **Hostname/IP** : `{globals().get('DOMAIN','N/A')}`
┃  🏢 **ISP**         : `{isp}`
┃  🌍 **Country**     : `{country}`
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bug_isat_()
    else:
        await event.answer("Access Denied", alert=True)
        
        
# === HANDLER TOMBOL-TOMBOL ===

@bot.on(events.CallbackQuery(data=b'create-bugxl'))
async def create_bugxl(event):
    msg = "🟢 Handler BUG XL dipanggil.\n\n# TODO: tambahkan logika generate config/bug XL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugaxis'))
async def create_bugaxis(event):
    msg = "🟢 Handler BUG AXIS dipanggil.\n\n# TODO: tambahkan logika generate config/bug AXIS di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugisat'))
async def create_bugisat(event):
    msg = "🟢 Handler BUG INDOSAT dipanggil.\n\n# TODO: tambahkan logika generate config/bug INDOSAT di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugtsel'))
async def create_bugtsel(event):
    msg = "🟢 Handler BUG TELKOMSEL dipanggil.\n\n# TODO: tambahkan logika generate config/bug TELKOMSEL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'cek-bug'))
async def cek_bug(event):
    msg = "🔎 Handler CEK BUG STATUS dipanggil.\n\n# TODO: tambahkan logika cek status bug/payload."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'tarobug'))
async def import_bug(event):
    msg = "📥 Handler IMPORT BUG & PAYLOAD dipanggil.\n\n# TODO: tambahkan logika import file/database bug."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])
    
        

# --- BUG TELKOMSEL (TSEL) ---
@bot.on(events.CallbackQuery(data=b'create-bugtsel'))
async def bug_tsel(event):
    async def bug_tsel_():
        inline = [
            [Button.inline("‹ MEMBER BUG TSEL ›","member-bugtsel")],
            [Button.inline(" CREATE BUG TSEL ","create-bugtsel-now"),
             Button.inline(" TRIAL BUG TSEL ","trial-bugtsel")],
            [Button.inline(" CHECK BUG TSEL ","cek-bugtsel"),
             Button.inline(" DELETE BUG TSEL ","delete-bugtsel")],
            [Button.inline(" LOCK BUG TSEL ","lock-bugtsel"),
             Button.inline(" UNLOCK BUG TSEL ","unlock-bugtsel")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "N/A")
            country = z.get("country", "N/A")
        except Exception:
            isp = "N/A"; country = "N/A"

        msg = f"""
╭━━━〔 🐾🕊️ BUG & PAYLOAD TELKOMSEL 🕊️🐾 〕
┃
┃  🔰 **Service**     : `BUG & PAYLOAD TELKOMSEL`
┃  🌐 **Hostname/IP** : `{globals().get('DOMAIN','N/A')}`
┃  🏢 **ISP**         : `{isp}`
┃  🌍 **Country**     : `{country}`
┃
┃  🤖 **Admin**       : @newbie_store24
╰━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bug_tsel_()
    else:
        await event.answer("Access Denied", alert=True)
        

# === HANDLER TOMBOL-TOMBOL ===

@bot.on(events.CallbackQuery(data=b'create-bugxl'))
async def create_bugxl(event):
    msg = "🟢 Handler BUG XL dipanggil.\n\n# TODO: tambahkan logika generate config/bug XL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugaxis'))
async def create_bugaxis(event):
    msg = "🟢 Handler BUG AXIS dipanggil.\n\n# TODO: tambahkan logika generate config/bug AXIS di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugisat'))
async def create_bugisat(event):
    msg = "🟢 Handler BUG INDOSAT dipanggil.\n\n# TODO: tambahkan logika generate config/bug INDOSAT di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'create-bugtsel'))
async def create_bugtsel(event):
    msg = "🟢 Handler BUG TELKOMSEL dipanggil.\n\n# TODO: tambahkan logika generate config/bug TELKOMSEL di sini."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'cek-bug'))
async def cek_bug(event):
    msg = "🔎 Handler CEK BUG STATUS dipanggil.\n\n# TODO: tambahkan logika cek status bug/payload."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])

@bot.on(events.CallbackQuery(data=b'tarobug'))
async def import_bug(event):
    msg = "📥 Handler IMPORT BUG & PAYLOAD dipanggil.\n\n# TODO: tambahkan logika import file/database bug."
    await event.edit(msg, buttons=[[Button.inline("‹ Back","bugall")]])
    
        
        
        