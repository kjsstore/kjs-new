# bugall.py
from kyt import *
import subprocess

# === HANDLER BUG & PAYLOAD (boleh dipanggil dari menu via callback 'bugall' atau command .bugall) ===
@bot.on(events.NewMessage(pattern=r"(?:.bugall|/bugall)$"))
@bot.on(events.CallbackQuery(data=b'bugall'))
async def bugall_handler(event):
    """
    Handler untuk MENU BUG & PAYLOAD
    - Dapat dipanggil lewat callback data 'bugall' atau command .bugall
    - Aman terhadap error: jika command/subprocess gagal, tampilkan 'N/A'
    """

    # Ambil info dasar server dengan fallback aman
    def safe_cmd(cmd):
        try:
            out = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode().strip()
            return out if out else "N/A"
        except Exception:
            return "N/A"

    namaos = safe_cmd("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").replace('"','')
    ipsaya = safe_cmd("curl -s ipv4.icanhazip.com")
    city = safe_cmd("cat /etc/xray/city")
    domain = globals().get("DOMAIN", "N/A")  # gunakan DOMAIN dari modul global kyt jika ada

    # Contoh statistik payload/bug — ganti path sesuai implementasimu.
    # Kode ini cuma mencoba beberapa lokasi umum dan fallback ke N/A bila tidak ada.
    payload_count = "N/A"
    try:
        # contoh: hitung file di /etc/bugall atau baris pada database
        payload_count = subprocess.check_output("if [ -d /etc/bugall ]; then ls -1 /etc/bugall | wc -l; elif [ -f /etc/bugall.db ]; then cat /etc/bugall.db | grep -c '###'; else echo 'N/A'; fi", shell=True, stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        payload_count = "N/A"

    # Inline buttons untuk fitur bug & payload — sesuaikan callback names dengan handler lainmu
    inline = [
        [Button.inline(" CREATE BUG ","create-bug")],
        [Button.inline(" LIST BUG / PAYLOAD ","list-bug")],
        [Button.inline(" IMPORT PAYLOAD ","import-payload"),
         Button.inline(" EXPORT PAYLOAD ","export-payload")],
        [Button.inline(" CHECK BUG STATUS ","cek-bug"),
         Button.inline(" DELETE BUG ","delete-bug")],
        [Button.inline(" ‹ Back to MENU › ","menu")]
    ]

    # Pesan tampilan — rapih dan sederhana
    msg = f"""
╭───〔 🐛 BUG & PAYLOAD MANAGER 🐛 〕
│
│ **» OS       :** `{namaos.strip()}`
│ **» CITY     :** `{city.strip()}`
│ **» DOMAIN   :** `{domain}`
│ **» IP VPS   :** `{ipsaya.strip()}`
│
│ **📦 Total Payloads / Bug Entries :** `{payload_count}`
│
╰───────────────────────────────╯
"""

    # Coba edit message (CallbackQuery biasanya bisa). Jika gagal (mis. dari chat message), kirim reply.
    try:
        await event.edit(msg, buttons=inline)
    except Exception:
        # beberapa event objek (NewMessage) mungkin tidak support edit pada konteks ini; fallback ke reply
        try:
            await event.reply(msg, buttons=inline)
        except Exception:
            # terakhir, fallback ke mengirim pesan biasa
            await event.respond(msg)

