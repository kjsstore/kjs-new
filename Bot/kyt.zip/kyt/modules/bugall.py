# bugall.py
from kyt import *
import subprocess
import requests

# === MENU BUG & PAYLOAD ===
@bot.on(events.NewMessage(pattern=r"(?:.bugall|/bugall)$"))
@bot.on(events.CallbackQuery(data=b'bugall'))
async def bugall_handler(event):
    def safe_cmd(cmd):
        try:
            out = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode().strip()
            return out if out else "N/A"
        except Exception:
            return "N/A"

    namaos = safe_cmd("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").replace('"','')
    ipsaya = safe_cmd("curl -s ipv4.icanhazip.com")
    city = safe_cmd("cat /etc/xray/city")
    domain = globals().get("DOMAIN", "N/A")

    payload_count = "N/A"
    try:
        payload_count = subprocess.check_output(
            "if [ -d /etc/bugall ]; then ls -1 /etc/bugall | wc -l; "
            "elif [ -f /etc/bugall.db ]; then cat /etc/bugall.db | grep -c '###'; "
            "else echo 'N/A'; fi",
            shell=True, stderr=subprocess.DEVNULL
        ).decode().strip()
    except Exception:
        payload_count = "N/A"

    inline = [
        [Button.inline(" BUG XL ","create-bugxl")],
        [Button.inline(" BUG AXIS ","create-bugaxis")],
        [Button.inline(" BUG ISAT ","create-bugisat"),
         Button.inline(" BUG TSEL ","create-bugtsel")],
        [Button.inline(" CHECK BUG ","cek-bug"),
         Button.inline(" IMPORT BUG ","tarobug")],
        [Button.inline(" ‹ BACK MENU › ","menu")]
    ]

    msg = f"""```
〔 🐛 BUG & PAYLOAD MANAGER 🐛 〕
    
```"""
    try:
        await event.edit(msg, buttons=inline)
    except Exception:
        try:
            await event.reply(msg, buttons=inline)
        except Exception:
            await event.respond(msg)


# === HANDLER TOMBOL-TOMBOL ===================================================

@bot.on(events.CallbackQuery(data=b'bugxl1'))
async def bugxl1(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD XL 🟢 〕
┃
┃  🔰 Service : BUG XL
┃  📡 Gunakan config khusus XL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugxl")]])


@bot.on(events.CallbackQuery(data=b'bugxl2'))
async def bugxl2(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD XL 🟢 〕
┃
┃  🔰 Service : BUG XL
┃  📡 Gunakan config khusus XL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugxl")]])


@bot.on(events.CallbackQuery(data=b'bugxl3'))
async def bugxl3(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD XL 🟢 〕
┃
┃  🔰 Service : BUG XL
┃  📡 Gunakan config khusus XL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugxl")]])


@bot.on(events.CallbackQuery(data=b'bugxl4'))
async def bugxl4(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD XL 🟢 〕
┃
┃  🔰 Service : BUG XL
┃  📡 Gunakan config khusus XL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugxl")]])


@bot.on(events.CallbackQuery(data=b'bugxl5'))
async def bugxl5(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD XL 🟢 〕
┃
┃  🔰 Service : BUG XL
┃  📡 Gunakan config khusus XL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugxl")]])


@bot.on(events.CallbackQuery(data=b'bugxl6'))
async def bugxl6(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD XL 🟢 〕
┃
┃  🔰 Service : BUG XL
┃  📡 Gunakan config khusus XL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugxl")]])
    
    
@bot.on(events.CallbackQuery(data=b'bugxl7'))
async def bugxl7(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD XL 🟢 〕
┃
┃  🔰 Service : BUG XL
┃  📡 Gunakan config khusus XL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugxl")]])

    


# --- BUG XL ---
@bot.on(events.CallbackQuery(data=b'create-bugxl'))
async def bug_xl(event):
    async def bug_xl_():
        inline = [
            [Button.inline("‹ XL BIZ STARTER ›","bugxl1")],
            [Button.inline(" XL BIZ LITE ","bugxl2"),
             Button.inline(" XL EDUKASI ","bugxl3")],
            [Button.inline(" XL IFLIX ","bugxl4"),
             Button.inline(" XL DB YOUTUBE ","bugxl5")],
            [Button.inline(" XL UTT ","bugxl6"),
             Button.inline(" XL GRAB ","bugxl7")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "N/A")
            country = z.get("country", "N/A")
        except Exception:
            isp = "N/A"; country = "N/A"

        msg = f"""```
〔 🐾🕊️ BUG & PAYLOAD XL 🕊️🐾 〕

```"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bug_xl_()
    else:
        await event.answer("Access Denied", alert=True)
        


# === HANDLER TOMBOL-TOMBOL BUG AXIS ===========================================

@bot.on(events.CallbackQuery(data=b'bugaxis1'))
async def bugaxis1(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD AXIS 🟢 〕
┃
┃  🔰 Service : BUG AXIS
┃  📡 Gunakan config khusus AXIS.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugaxis")]])


@bot.on(events.CallbackQuery(data=b'bugaxis2'))
async def bugaxis2(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD AXIS 🟢 〕
┃
┃  🔰 Service : BUG AXIS
┃  📡 Gunakan config khusus AXIS.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugaxis")]])


@bot.on(events.CallbackQuery(data=b'bugaxis3'))
async def bugaxis3(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD AXIS 🟢 〕
┃
┃  🔰 Service : BUG AXIS
┃  📡 Gunakan config khusus AXIS.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugaxis")]])


@bot.on(events.CallbackQuery(data=b'bugaxis4'))
async def bugaxis4(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD AXIS 🟢 〕
┃
┃  🔰 Service : BUG AXIS
┃  📡 Gunakan config khusus AXIS.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugaxis")]])


@bot.on(events.CallbackQuery(data=b'bugaxis5'))
async def bugaxis5(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD AXIS 🟢 〕
┃
┃  🔰 Service : BUG AXIS
┃  📡 Gunakan config khusus AXIS.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugaxis")]])


@bot.on(events.CallbackQuery(data=b'bugaxis6'))
async def bugaxis6(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD AXIS 🟢 〕
┃
┃  🔰 Service : BUG AXIS
┃  📡 Gunakan config khusus AXIS.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugaxis")]])


@bot.on(events.CallbackQuery(data=b'bugaxis7'))
async def bugaxis7(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD AXIS 🟢 〕
┃
┃  🔰 Service : BUG AXIS
┃  📡 Gunakan config khusus AXIS.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugaxis")]])
    
    
          


# --- BUG AXIS ---
@bot.on(events.CallbackQuery(data=b'create-bugaxis'))
async def bug_axis(event):
    async def bug_axis_():
        inline = [
            [Button.inline("‹ MEMBER BUG AXIS ›","member-bugaxis")],
            [Button.inline(" CREATE BUG AXIS ","create-bugaxis-now"),
             Button.inline(" TRIAL BUG AXIS ","trial-bugaxis")],
            [Button.inline(" CHECK BUG AXIS ","cek-bugaxis"),
             Button.inline(" DELETE BUG AXIS ","delete-bugaxis")],
            [Button.inline(" LOCK BUG AXIS ","lock-bugaxis"),
             Button.inline(" UNLOCK BUG AXIS ","unlock-bugaxis")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "N/A")
            country = z.get("country", "N/A")
        except Exception:
            isp = "N/A"; country = "N/A"

        msg = f"""```
〔 🐾🕊️ BUG & PAYLOAD AXIS 🕊️🐾 〕

```"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bug_axis_()
    else:
        await event.answer("Access Denied", alert=True)
        

# === HANDLER TOMBOL-TOMBOL BUG ISAT ===========================================

@bot.on(events.CallbackQuery(data=b'bugisat1'))
async def bugisat1(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD ISAT 🟢 〕
┃
┃  🔰 Service : BUG INDOSAT
┃  📡 Gunakan config khusus INDOSAT.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugisat")]])


@bot.on(events.CallbackQuery(data=b'bugisat2'))
async def bugisat2(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD ISAT 🟢 〕
┃
┃  🔰 Service : BUG INDOSAT
┃  📡 Gunakan config khusus INDOSAT.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugisat")]])


@bot.on(events.CallbackQuery(data=b'bugisat3'))
async def bugisat3(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD ISAT 🟢 〕
┃
┃  🔰 Service : BUG INDOSAT
┃  📡 Gunakan config khusus INDOSAT.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugisat")]])


@bot.on(events.CallbackQuery(data=b'bugisat4'))
async def bugisat4(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD ISAT 🟢 〕
┃
┃  🔰 Service : BUG INDOSAT
┃  📡 Gunakan config khusus INDOSAT.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugisat")]])


@bot.on(events.CallbackQuery(data=b'bugisat5'))
async def bugisat5(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD ISAT 🟢 〕
┃
┃  🔰 Service : BUG INDOSAT
┃  📡 Gunakan config khusus INDOSAT.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugisat")]])


@bot.on(events.CallbackQuery(data=b'bugisat6'))
async def bugisat6(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD ISAT 🟢 〕
┃
┃  🔰 Service : BUG INDOSAT
┃  📡 Gunakan config khusus INDOSAT.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugisat")]])


@bot.on(events.CallbackQuery(data=b'bugisat7'))
async def bugisat7(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD ISAT 🟢 〕
┃
┃  🔰 Service : BUG INDOSAT
┃  📡 Gunakan config khusus INDOSAT.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugisat")]])
    
    
        


# --- BUG INDOSAT (ISAT) ---
@bot.on(events.CallbackQuery(data=b'create-bugisat'))
async def bug_isat(event):
    async def bug_isat_():
        inline = [
            [Button.inline("‹ MEMBER BUG ISAT ›","member-bugisat")],
            [Button.inline(" CREATE BUG ISAT ","create-bugisat-now"),
             Button.inline(" TRIAL BUG ISAT ","trial-bugisat")],
            [Button.inline(" CHECK BUG ISAT ","cek-bugisat"),
             Button.inline(" DELETE BUG ISAT ","delete-bugisat")],
            [Button.inline(" LOCK BUG ISAT ","lock-bugisat"),
             Button.inline(" UNLOCK BUG ISAT ","unlock-bugisat")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "N/A")
            country = z.get("country", "N/A")
        except Exception:
            isp = "N/A"; country = "N/A"

        msg = f"""```
〔 🕊️ BUG & PAYLOAD INDOSAT 🕊️ 〕

```"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bug_isat_()
    else:
        await event.answer("Access Denied", alert=True)
        
        
# === HANDLER TOMBOL-TOMBOL BUG TSEL ===========================================

@bot.on(events.CallbackQuery(data=b'bugtsel1'))
async def bugtsel1(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD TSEL 🟢 〕
┃
┃  🔰 Service : BUG TELKOMSEL
┃  📡 Gunakan config khusus TELKOMSEL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugtsel")]])


@bot.on(events.CallbackQuery(data=b'bugtsel2'))
async def bugtsel2(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD TSEL 🟢 〕
┃
┃  🔰 Service : BUG TELKOMSEL
┃  📡 Gunakan config khusus TELKOMSEL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugtsel")]])


@bot.on(events.CallbackQuery(data=b'bugtsel3'))
async def bugtsel3(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD TSEL 🟢 〕
┃
┃  🔰 Service : BUG TELKOMSEL
┃  📡 Gunakan config khusus TELKOMSEL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugtsel")]])


@bot.on(events.CallbackQuery(data=b'bugtsel4'))
async def bugtsel4(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD TSEL 🟢 〕
┃
┃  🔰 Service : BUG TELKOMSEL
┃  📡 Gunakan config khusus TELKOMSEL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugtsel")]])


@bot.on(events.CallbackQuery(data=b'bugtsel5'))
async def bugtsel5(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD TSEL 🟢 〕
┃
┃  🔰 Service : BUG TELKOMSEL
┃  📡 Gunakan config khusus TELKOMSEL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugtsel")]])


@bot.on(events.CallbackQuery(data=b'bugtsel6'))
async def bugtsel6(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD TSEL 🟢 〕
┃
┃  🔰 Service : BUG TELKOMSEL
┃  📡 Gunakan config khusus TELKOMSEL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugtsel")]])


@bot.on(events.CallbackQuery(data=b'bugtsel7'))
async def bugtsel7(event):
    msg = """
╭━━━〔 🟢 BUG & PAYLOAD TSEL 🟢 〕
┃
┃  🔰 Service : BUG TELKOMSEL
┃  📡 Gunakan config khusus TELKOMSEL.
┃
╰━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=[[Button.inline("‹ Back","create-bugtsel")]])
    

    
        

# --- BUG TELKOMSEL (TSEL) ---
@bot.on(events.CallbackQuery(data=b'create-bugtsel'))
async def bug_tsel(event):
    async def bug_tsel_():
        inline = [
            [Button.inline("‹ MEMBER BUG TSEL ›","member-bugtsel")],
            [Button.inline(" CREATE BUG TSEL ","create-bugtsel-now"),
             Button.inline(" TRIAL BUG TSEL ","trial-bugtsel")],
            [Button.inline(" CHECK BUG TSEL ","cek-bugtsel"),
             Button.inline(" DELETE BUG TSEL ","delete-bugtsel")],
            [Button.inline(" LOCK BUG TSEL ","lock-bugtsel"),
             Button.inline(" UNLOCK BUG TSEL ","unlock-bugtsel")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "N/A")
            country = z.get("country", "N/A")
        except Exception:
            isp = "N/A"; country = "N/A"

        msg = f"""```
〔 🐾 BUG & PAYLOAD TELKOMSEL 🐾 〕

```"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await bug_tsel_()
    else:
        await event.answer("Access Denied", alert=True)
        

# === HANDLER TOMBOL-TOMBOL ===

    
        
        
        