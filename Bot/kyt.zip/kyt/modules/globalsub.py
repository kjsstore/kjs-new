# globalsub.py
# ==============================
# 🌐 Konfigurasi Cloudflare Domain
# ==============================

global_subdomain = {
    "metsstore.my.id": {
        "zone": "cba3faf2552ec450b17b6d374ccafec6",
        "apitoken": "CxvETgUXFLios9C4hfFcLYdxdj76gAtjgc-LzJBO"
    },
    "server-kjs.my.id": {
        "zone": "5f9be36876295d6a243d124feea09b5c",
        "apitoken": "CxvETgUXFLios9C4hfFcLYdxdj76gAtjgc-LzJBO"
    }
    # Tambah domain lain disini
}
