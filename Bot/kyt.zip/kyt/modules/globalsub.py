# globalsub.py
# ==============================
# 🌐 Konfigurasi Cloudflare Domain
# ==============================

global_subdomain = {
    "metsstore.my.id": {
        "zone": "ZONE_ID_DISINI",
        "apitoken": "API_TOKEN_DISINI"
    },
    "kjs-tunneling.site": {
        "zone": "ZONE_ID_DISINI",
        "apitoken": "API_TOKEN_DISINI"
    }
    # Tambah domain lain disini
}
