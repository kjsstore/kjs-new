# pointing.py
from kyt import *

# ---------- SESSION ----------
user_pointing_session = {}

# ---------- POINTING CREATE / UPDATE ----------
@bot.on(events.CallbackQuery(data=b'pointing-create'))
async def pointing_create(event):
    uid = event.sender_id
    user_pointing_session[uid] = {}

    await event.edit("❗ Kirim *IP Address* untuk pointing domain/subdomain:")

    # Langkah 1: Input IP
    @bot.on(events.NewMessage(from_users=uid))
    async def input_ip(e):
        ip = e.text.strip()
        if not re.match(r"^(\d{1,3}\.){3}\d{1,3}$", ip):
            return await e.reply(f"⚠️ Format IP tidak valid: *{ip}*")
        user_pointing_session[uid]["ip"] = ip
        await e.reply("✅ IP diterima! Sekarang kirim *Domain/Subdomain* untuk pointing:")
        bot.remove_event_handler(input_ip)

        # Langkah 2: Input Domain
        @bot.on(events.NewMessage(from_users=uid))
        async def input_domain(f):
            full_domain = f.text.lower().strip()
            # Cek domain di globalsub
            domain = next((d for d in global_subdomain if full_domain.endswith(d)), None)
            if not domain:
                return await f.reply(f"❌ Domain *{full_domain}* tidak terdaftar!")

            ip_addr = user_pointing_session[uid]["ip"]
            zone = global_subdomain[domain]["zone"]
            apitoken = global_subdomain[domain]["apitoken"]
            headers = {"Authorization": f"Bearer {apitoken}", "Content-Type": "application/json"}

            try:
                # Hapus record A lama
                res = requests.get(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records?type=A&name={full_domain}", headers=headers).json()
                for rec in res.get("result", []):
                    requests.delete(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records/{rec['id']}", headers=headers)

                # Buat record A baru
                body = {"type": "A", "name": full_domain, "content": ip_addr, "ttl": 1, "proxied": False}
                res_create = requests.post(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records", headers=headers, data=json.dumps(body)).json()

                if res_create.get("success"):
                    await f.reply(f"✅ Record A *{full_domain}* berhasil dibuat/di-update ke IP *{ip_addr}*!")
                else:
                    await f.reply(f"❌ Gagal pointing!\n{json.dumps(res_create.get('errors', []), indent=2)}")
            except Exception as err:
                await f.reply(f"❌ Terjadi error: {err}")
            finally:
                user_pointing_session.pop(uid, None)
                bot.remove_event_handler(input_domain)
