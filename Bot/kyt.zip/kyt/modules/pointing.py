# pointing.py
from kyt import *
import re, json, requests
import asyncio  # untuk animasi delay

# ---------- SESSION ----------
user_pointing_session = {}

# ---------- HELPERS ----------
def is_valid_ip(ip):
    pattern = r"^(\d{1,3}\.){3}\d{1,3}$"
    return re.match(pattern, ip)

# ---------- POINTING CREATE / UPDATE ----------
@bot.on(events.CallbackQuery(data=b'pointing-cf'))
async def pointing_cf(event):
    uid = event.sender_id
    user_pointing_session[uid] = {"step": "ip"}  # Track step

    await event.edit("❗ Kirim *IP Address* untuk pointing domain/subdomain:")

# ---------- INPUT MESSAGE HANDLER ----------
@bot.on(events.NewMessage)
async def handle_pointing_input(e):
    uid = e.sender_id
    if uid not in user_pointing_session:
        return  # Ignore if not in session

    session = user_pointing_session[uid]

    if session["step"] == "ip":
        ip = e.text.strip()
        if not is_valid_ip(ip):
            return await e.reply(f"⚠️ Format IP tidak valid: *{ip}*")
        session["ip"] = ip
        session["step"] = "domain"
        return await e.reply("✅ IP diterima! Sekarang kirim *Domain/Subdomain* untuk pointing:")

    elif session["step"] == "domain":
        full_domain = e.text.lower().strip()
        # Cari domain di global_subdomain
        domain_key = next((d for d in global_subdomain if full_domain.endswith(d)), None)
        if not domain_key:
            return await e.reply(f"❌ Domain *{full_domain}* tidak terdaftar!")

        ip_addr = session["ip"]
        zone = global_subdomain[domain_key]["zone"]
        apitoken = global_subdomain[domain_key]["apitoken"]
        headers = {"Authorization": f"Bearer {apitoken}", "Content-Type": "application/json"}

        try:
            # Hapus record A lama
            res = requests.get(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records?type=A&name={full_domain}", headers=headers).json()
            for rec in res.get("result", []):
                requests.delete(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records/{rec['id']}", headers=headers)

            # Buat record A baru
            body = {"type": "A", "name": full_domain, "content": ip_addr, "ttl": 1, "proxied": False}
            res_create = requests.post(f"https://api.cloudflare.com/client/v4/zones/{zone}/dns_records", headers=headers, data=json.dumps(body)).json()

            if res_create.get("success"):
                # Animasi pulsing "Processing..."
                msg = await e.reply("🔄 Processing pointing")
                for i in range(1, 5):
                    await asyncio.sleep(0.5)
                    await msg.edit(f"🔄 Processing pointing{'.'*i}")

                # Tampilkan Done Box keren
                done_msg = f"""
✅━━━━━━━━━━━━━━━━━━✅
🎯 *Pointing Selesai!* 🎯

🌐 Domain/Subdomain: `{full_domain}`
📌 IP Address: `{ip_addr}`

🚀 DNS record berhasil dibuat/di-update di Cloudflare!
✅━━━━━━━━━━━━━━━━━━✅
"""
                await msg.edit(done_msg)
            else:
                await e.reply(f"❌ Gagal pointing!\n{json.dumps(res_create.get('errors', []), indent=2)}")

        except Exception as err:
            await e.reply(f"❌ Terjadi error: {err}")

        finally:
            user_pointing_session.pop(uid, None)
