# ============================================
#  KJS - CLOUDFLARE MANAGER (CLI TEXT VERSION - FULL FIXED)
# ============================================

import os, json, stat, subprocess, aiohttp
from telethon import events, Button

CFG_PATH = "/etc/kyt/cloudflare.json"

# ---------- UTIL ----------
def safe_cmd(cmd):
    try:
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode().strip()
        return out if out else "N/A"
    except Exception:
        return "N/A"

def load_config():
    if not os.path.exists(CFG_PATH):
        return {}
    try:
        with open(CFG_PATH, "r") as f:
            return json.load(f)
    except Exception:
        return {}

def save_config(cfg):
    os.makedirs(os.path.dirname(CFG_PATH), exist_ok=True)
    tmp = CFG_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cfg, f, indent=2)
    os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    os.replace(tmp, CFG_PATH)

def get_cf_headers(cfg):
    if cfg.get("auth_mode") == "global_key":
        return {
            "X-Auth-Email": cfg.get("email", ""),
            "X-Auth-Key": cfg.get("api_key", ""),
            "Content-Type": "application/json"
        }
    else:
        return {
            "Authorization": f"Bearer {cfg.get('token','')}",
            "Content-Type": "application/json"
        }

# ---------- HTTP REQUEST ----------
async def cf_request(session, method, path, cfg, params=None, jsonbody=None):
    url = f"https://api.cloudflare.com/client/v4{path}"
    headers = get_cf_headers(cfg)
    try:
        async with session.request(method, url, headers=headers, params=params, json=jsonbody, timeout=30) as resp:
            text = await resp.text()
            try:
                data = await resp.json()
            except Exception:
                data = {"success": False, "errors": [{"message": f"bad-json: {text[:300]}"}]}
            return resp.status, data
    except Exception as e:
        return 500, {"success": False, "errors": [{"message": str(e)}]}

# ---------- CF CORE ----------
async def get_zone_id(session, cfg, zone_name):
    status, data = await cf_request(session, "GET", "/zones", cfg, params={"name": zone_name})
    if status == 200 and data.get("success"):
        res = data.get("result", [])
        if res:
            return res[0]["id"]
    return None

async def list_zone_records(session, cfg, zone_id, rtype=None, page=1, per_page=100):
    params = {"page": page, "per_page": per_page}
    if rtype:
        params["type"] = rtype
    status, data = await cf_request(session, "GET", f"/zones/{zone_id}/dns_records", cfg, params=params)
    if status == 200 and data.get("success"):
        return data.get("result", [])
    return []

async def find_record(session, cfg, zone_id, name, rtype=None):
    params = {"name": name}
    if rtype:
        params["type"] = rtype
    status, data = await cf_request(session, "GET", f"/zones/{zone_id}/dns_records", cfg, params=params)
    if status == 200 and data.get("success"):
        return data.get("result", [])
    return []

async def create_record(session, cfg, zone_id, rtype, name, content, proxied=False, ttl=1):
    body = {"type": rtype, "name": name, "content": content, "ttl": ttl, "proxied": proxied}
    return await cf_request(session, "POST", f"/zones/{zone_id}/dns_records", cfg, jsonbody=body)

async def update_record(session, cfg, zone_id, rec_id, rtype, name, content, proxied=False, ttl=1):
    body = {"type": rtype, "name": name, "content": content, "ttl": ttl, "proxied": proxied}
    return await cf_request(session, "PUT", f"/zones/{zone_id}/dns_records/{rec_id}", cfg, jsonbody=body)

async def delete_record(session, cfg, zone_id, rec_id):
    return await cf_request(session, "DELETE", f"/zones/{zone_id}/dns_records/{rec_id}", cfg)

# high-level upsert
async def upsert_record(cfg, rtype, full_name, content, proxied=False):
    async with aiohttp.ClientSession() as session:
        zone = cfg.get("zone")
        zone_id = await get_zone_id(session, cfg, zone)
        if not zone_id:
            return False, f"Zone `{zone}` tidak ditemukan."
        existing = await find_record(session, cfg, zone_id, full_name, rtype)
        if existing:
            rec = existing[0]
            rec_id = rec["id"]
            if rec.get("content") == content and rec.get("proxied") == proxied:
                return True, f"{rtype} `{full_name}` sudah mengarah ke {content}."
            status, data = await update_record(session, cfg, zone_id, rec_id, rtype, full_name, content, proxied=proxied)
        else:
            status, data = await create_record(session, cfg, zone_id, rtype, full_name, content, proxied=proxied)
        if status in (200,201) and data.get("success"):
            return True, f"{rtype} `{full_name}` berhasil diset ke {content}."
        return False, f"Gagal operasi: {data}"

# ---------- CF MENU ----------
@bot.on(events.NewMessage(pattern=r"(?:.cfmenu|/cfmenu)$"))
@bot.on(events.CallbackQuery(pattern=b'cfmenu'))
async def cfmenu_handler(event):
    inline = [
        [Button.inline("➕ ADD CLOUDFLARE ACCOUNT", b'addcf-menu')],
        [Button.inline("🌍 SET ZONE", b'setzone-menu')],
        [Button.inline("📡 POINTING DOMAIN", b'pointing-menu')],
        [Button.inline("📋 LIST POINTING", b'listpoint-menu')],
        [Button.inline("♻️ UPDATE POINTING", b'updatepoint-menu')],
        [Button.inline("❌ DELETE POINTING", b'delpoint-menu')],
        [Button.inline("ℹ️ ACCOUNT INFO", b'cfinfo-menu')],
        [Button.inline("‹ BACK MENU ›", b'menu')]
    ]

    msg = f"""```
〔 🌐 CLOUDFLARE MANAGER 🌐 〕

Kelola domain kamu langsung dari bot ini.
Gunakan tombol di bawah untuk mengatur:
```"""
    try:
        if isinstance(event, events.CallbackQuery):
            await event.edit(msg, buttons=inline)
        else:
            await event.reply(msg, buttons=inline)
    except Exception as e:
        await event.reply(f"Terjadi error: {e}", buttons=inline)

# ---------- CALLBACK HANDLERS ----------
@bot.on(events.CallbackQuery(pattern=b'addcf-menu'))
async def cb_addcf(event):
    await event.edit("📥 Gunakan perintah:\n`/addcf <API_KEY> <EMAIL>`\nContoh:\n`/addcf 05cbd81c22668a6fd8c59f895c45fabd2255e email@gmail.com`")

@bot.on(events.CallbackQuery(pattern=b'setzone-menu'))
async def cb_setzone(event):
    await event.edit("🌍 Gunakan perintah:\n`/setcfzone <domain>`\nContoh:\n`/setcfzone example.com`")

@bot.on(events.CallbackQuery(pattern=b'pointing-menu'))
async def cb_pointing(event):
    await event.edit("📡 Gunakan perintah:\n`/pointing <IP> <full.domain>`\nContoh:\n`/pointing 123.45.67.89 sub.example.com`\nWildcard akan otomatis dibuat.")

@bot.on(events.CallbackQuery(pattern=b'listpoint-menu'))
async def cb_listpoint(event):
    await event.edit("📋 Gunakan perintah:\n`/listpoint`\nMenampilkan semua DNS record aktif.")

@bot.on(events.CallbackQuery(pattern=b'updatepoint-menu'))
async def cb_updatepoint(event):
    await event.edit("♻️ Gunakan perintah:\n`/updatepoint <full.domain> <IP>`\nContoh:\n`/updatepoint sub.example.com 123.45.67.89`")

@bot.on(events.CallbackQuery(pattern=b'delpoint-menu'))
async def cb_delpoint(event):
    await event.edit("❌ Gunakan perintah:\n`/delpoint <full.domain>`\nContoh:\n`/delpoint sub.example.com`")

@bot.on(events.CallbackQuery(pattern=b'cfinfo-menu'))
async def cb_cfinfo(event):
    await event.edit("ℹ️ Gunakan perintah:\n`/cfinfo`\nMelihat info akun Cloudflare aktif.")

# ---------- COMMAND HANDLERS ----------
@bot.on(events.NewMessage(pattern=r"(?:/addcf)\s+([^\s]+)\s+([^\s]+)$"))
async def addcf_handler(event):
    api_key = event.pattern_match.group(1).strip()
    email = event.pattern_match.group(2).strip()
    cfg = load_config()
    cfg["auth_mode"] = "global_key"
    cfg["api_key"] = api_key
    cfg["email"] = email
    save_config(cfg)
    async with aiohttp.ClientSession() as session:
        status, data = await cf_request(session, "GET", "/user", cfg)
        if data.get("success"):
            usr = data["result"]["email"]
            await event.reply(f"✅ Login berhasil: `{usr}`\nConfig disimpan: `{CFG_PATH}`")
        else:
            await event.reply(f"❌ Gagal login Cloudflare. Periksa API key & email.\n{json.dumps(data, indent=2)}")

@bot.on(events.NewMessage(pattern=r"(?:/setcfzone)\s+([^\s]+)$"))
async def setcfzone_handler(event):
    zone = event.pattern_match.group(1).strip().lower()
    cfg = load_config()
    cfg["zone"] = zone
    save_config(cfg)
    await event.reply(f"✅ Zone disimpan: `{zone}`")

@bot.on(events.NewMessage(pattern=r"(?:/cfinfo)$"))
async def cfinfo_handler(event):
    cfg = load_config()
    if not cfg.get("email") and not cfg.get("token"):
        await event.reply("⚠️ Belum login. Gunakan `/addcf <API_KEY> <EMAIL>`.")
        return
    async with aiohttp.ClientSession() as session:
        status, data = await cf_request(session, "GET", "/user", cfg)
        if not data.get("success"):
            await event.reply("❌ Login gagal (token/API key invalid).")
            return
        usr = data["result"]["email"]
        zone = cfg.get("zone","Belum diset")
        ip = safe_cmd("curl -s ipv4.icanhazip.com")
        await event.reply(f"Cloudflare Info:\n- Akun: `{usr}`\n- Zone: `{zone}`\n- IP VPS: `{ip}`\n- Mode: `{cfg.get('auth_mode','token')}`")

# ---------- /pointing ----------
@bot.on(events.NewMessage(pattern=r"(?:/pointing)\s+([^\s]+)\s+([^\s]+)$"))
async def pointing_handler(event):
    ip = event.pattern_match.group(1).strip()
    full_domain = event.pattern_match.group(2).strip().lower().rstrip(".")
    cfg = load_config()
    if not cfg.get("zone"):
        await event.reply("⚠️ Zone belum diset.")
        return
    zone = cfg["zone"]
    if not full_domain.endswith(zone):
        await event.reply(f"⚠️ Domain `{full_domain}` bukan bagian dari zone `{zone}`.")
        return
    await event.reply(f"⏳ Menyiapkan pointing `{full_domain}` → {ip} ...")
    ok_a, msg_a = await upsert_record(cfg, "A", full_domain, ip, proxied=False)
    msg_final = msg_a
    if full_domain != zone:
        sub = full_domain[:-(len(zone)+1)]
        wildcard = f"*.{sub}.{zone}"
        ok_c, msg_c = await upsert_record(cfg, "CNAME", wildcard, full_domain, proxied=False)
        msg_final += "\n" + msg_c
    await event.reply(msg_final)

# ---------- /listpoint ----------
@bot.on(events.NewMessage(pattern=r"(?:/listpoint)$"))
async def listpoint_handler(event):
    cfg = load_config()
    if not cfg.get("zone"):
        await event.reply("⚠️ Zone belum diset.")
        return
    zone = cfg["zone"]
    async with aiohttp.ClientSession() as session:
        zid = await get_zone_id(session, cfg, zone)
        if not zid:
            await event.reply(f"⚠️ Zone `{zone}` tidak ditemukan atau akses ditolak.")
            return
        a_records = await list_zone_records(session, cfg, zid, rtype="A", page=1, per_page=200)
        c_records = await list_zone_records(session, cfg, zid, rtype="CNAME", page=1, per_page=200)
        lines = [f"List DNS untuk zone `{zone}`:"]
        if a_records:
            lines.append("\n-- A Records --")
            for r in a_records:
                lines.append(f"{r.get('name')} -> {r.get('content')} (proxied={r.get('proxied')})")
        else:
            lines.append("\n-- A Records --\n(empty)")
        if c_records:
            lines.append("\n-- CNAME Records --")
            for r in c_records:
                lines.append(f"{r.get('name')} -> {r.get('content')} (proxied={r.get('proxied')})")
        else:
            lines.append("\n-- CNAME Records --\n(empty)")
        await event.reply("\n".join(lines))

# ---------- /delpoint ----------
@bot.on(events.NewMessage(pattern=r"(?:/delpoint)\s+([^\s]+)$"))
async def delpoint_handler(event):
    full_domain = event.pattern_match.group(1).strip().lower().rstrip(".")
    cfg = load_config()
    if not cfg.get("zone"):
        await event.reply("⚠️ Zone belum diset.")
        return
    zone = cfg["zone"]
    if not full_domain.endswith(zone):
        await event.reply(f"⚠️ `{full_domain}` bukan bagian dari zone `{zone}`.")
        return
    async with aiohttp.ClientSession() as session:
        zid = await get_zone_id(session, cfg, zone)
        if not zid:
            await event.reply("⚠️ Zone tidak ditemukan.")
            return
        found = []
        for rtype in ("A","CNAME","AAAA","TXT","MX"):
            recs = await find_record(session, cfg, zid, full_domain, rtype=rtype)
            for rec in recs:
                status, data = await delete_record(session, cfg, zid, rec["id"])
                if status in (200, 204) or data.get("success"):
                    found.append(f"Deleted {rtype} {full_domain}")
                else:
                    found.append(f"Failed delete {rtype} {full_domain}: {data}")
        if full_domain != zone:
            sub = full_domain[:-(len(zone)+1)]
            wildcard = f"*.{sub}.{zone}"
            recs = await find_record(session, cfg, zid, wildcard, rtype="CNAME")
            for rec in recs:
                status, data = await delete_record(session, cfg, zid, rec["id"])
                if status in (200,204) or data.get("success"):
                    found.append(f"Deleted CNAME {wildcard}")
                else:
                    found.append(f"Failed delete CNAME {wildcard}: {data}")
        if not found:
            await event.reply("❗ Tidak ditemukan record untuk dihapus.")
        else:
            await event.reply("Hasil penghapusan:\n" + "\n".join(found))

# ---------- /updatepoint ----------
@bot.on(events.NewMessage(pattern=r"(?:/updatepoint)\s+([^\s]+)\s+([^\s]+)$"))
async def updatepoint_handler(event):
    full_domain = event.pattern_match.group(1).strip().lower().rstrip(".")
    new_ip = event.pattern_match.group(2).strip()
    cfg = load_config()
    if not cfg.get("zone"):
        await event.reply("⚠️ Zone belum diset.")
        return
    zone = cfg["zone"]
    if not full_domain.endswith(zone):
        await event.reply(f"⚠️ `{full_domain}` bukan bagian dari zone `{zone}`.")
        return
    await event.reply(f"⏳ Updating {full_domain} -> {new_ip} ...")
    ok, msg = await upsert_record(cfg, "A", full_domain, new_ip, proxied=False)
    msg_final = msg
    if full_domain != zone:
        sub = full_domain[:-(len(zone)+1)]
        wildcard = f"*.{sub}.{zone}"
        async with aiohttp.ClientSession() as session:
            zid = await get_zone_id(session, cfg, zone)
            if zid:
                recs = await find_record(session, cfg, zid, wildcard, rtype="CNAME")
                if recs:
                    msg_final += f"\nWildcard {wildcard} exists -> no change (points to {full_domain})"
    await event.reply(msg_final)
