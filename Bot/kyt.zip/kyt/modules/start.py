from kyt import *
import subprocess
import asyncio

# === START MENU TANPA ANIMASI ===
@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # === Ambil data server langsung tanpa animasi ===
    ssh = subprocess.check_output('cat /etc/ssh/.ssh.db | grep "###" | wc -l', shell=True).decode()
    vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode()
    vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode()
    trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode()
    namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode()
    ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode()
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode()

    msg = f"""```
╭━〔 🐾🕊️ PREMIUM PANEL 🕊️🐾 〕
┃
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {DOMAIN}
┃  • IP VPS         : {ipsaya.strip()}
┃  • OS             : {namaos.strip().replace('"','')}
┃  • CITY           : {city.strip()}
┃
┃━━━━━━━〔 Statistik Akun 〕
┃  📊 Ringkasan :
┃  ├  🚀 SSH OVPN    : {ssh.strip()}
┃  ├  🎭 XRAY VMESS  : {vms.strip()}
┃  ├  🗼 XRAY VLESS  : {vls.strip()}
┃  └  🎯 XRAY TROJAN : {trj.strip()}
┃
┃━━━━━━━〔 Informasi Penting 〕
┃  ⚠️ PERHATIAN :
┃  • Gunakan akun sesuai aturan
┃  • Backup config penting
┃  • Add-on hanya dari panel resmi
┃
┃━━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
```"""

    inline = [
        [Button.inline("⚡ PANEL CREATE ACCOUNT ⚡", b"menu")],
        [Button.inline("🌩 CLOUDFLARE MANAGER 🌩", b"cfmenu")],
        [Button.inline("🧰 RESET CONFIG (Fresh Restart)", b"reset")],
        [Button.url("💬 PRIVATE KJS", "https://t.me/Kjsrealfamily"),
         Button.url("📞 WHATSAPP KJS", "https://wa.me/6285943111681")]
    ]

    banner_url = "https://files.catbox.moe/evzql8.jpg"

    if isinstance(event, events.CallbackQuery.Event):
        await event.edit(msg, buttons=inline)
    else:
        try:
            await bot.send_file(
                event.chat_id,
                banner_url,
                caption=msg,
                buttons=inline
            )
        except:
            await event.reply(msg, buttons=inline)


# === RESET CONFIG HANDLER ===
@bot.on(events.CallbackQuery(data=b'reset'))
async def reset_config_handler(event):
    try:
        # Hapus config lama + ganti dengan default
        subprocess.call("rm -rf /etc/kyt/config.json", shell=True)
        subprocess.call("cp /etc/kyt/config.default.json /etc/kyt/config.json", shell=True)

        # Restart service
        subprocess.call("systemctl restart kyt", shell=True)

        await event.answer("✅ Config berhasil direset & service direstart!", alert=True)
    except Exception as e:
        await event.answer(f"❌ Gagal reset config: {e}", alert=True)
