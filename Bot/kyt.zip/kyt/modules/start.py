from kyt import *
import subprocess
import asyncio

# === START MENU FULL CHAT BUBBLE ===
@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # --- Ambil data server ---
    ssh = subprocess.getoutput('cat /etc/ssh/.ssh.db | grep "###" | wc -l')
    vms = subprocess.getoutput('cat /etc/vmess/.vmess.db | grep "###" | wc -l')
    vls = subprocess.getoutput('cat /etc/vless/.vless.db | grep "###" | wc -l')
    trj = subprocess.getoutput('cat /etc/trojan/.trojan.db | grep "###" | wc -l')
    namaos = subprocess.getoutput("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | cut -d= -f2").replace('"','')
    ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    city = subprocess.getoutput("cat /etc/xray/city")

    # --- Pesan chat bubble ---
    msg = f"""```
╭━〔 🐾🕊️ PREMIUM PANEL 🕊️🐾 〕
┃
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {DOMAIN}
┃  • IP VPS         : {ipsaya.strip()}
┃  • OS             : {namaos.strip()}
┃  • CITY           : {city.strip()}
┃
┃━━━━━━━〔 Statistik Akun 〕
┃  📊 Ringkasan :
┃  ├  🚀 SSH OVPN    : {ssh.strip()}
┃  ├  🎭 XRAY VMESS  : {vms.strip()}
┃  ├  🗼 XRAY VLESS  : {vls.strip()}
┃  └  🎯 XRAY TROJAN : {trj.strip()}
┃
┃━━━━━━━〔 Informasi Penting 〕
┃  ⚠️ PERHATIAN :
┃  • Gunakan akun sesuai aturan
┃  • Backup config penting
┃  • Add-on hanya dari panel resmi
┃
┃━━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
```"""

    # --- Inline keyboard di bawah chat bubble ---
    inline = [
        [Button.inline("⚡ CREATE ACCOUNT ⚡", b"menu")],
        [Button.inline("🌩 MENU CF 🌩", b"cfmenu"),
         Button.inline("🧰 REFRESH 🧰", b"reset")],
        [Button.url("💬 PRIVATE KJS", "https://t.me/Kjsrealfamily"),
         Button.url("📞 WHATSAPP KJS", "https://wa.me/6285943111681")]
    ]

    # --- Kirim pesan bubble dengan tombol ---
    if isinstance(event, events.CallbackQuery.Event):
        await event.edit(msg, buttons=inline)
    else:
        await event.reply(msg, buttons=inline)


# === RESET CONFIG HANDLER ===
@bot.on(events.CallbackQuery(data=b'reset'))
async def reset_config_handler(event):
    try:
        subprocess.call("rm -rf /etc/kyt/config.json", shell=True)
        subprocess.call("cp /etc/kyt/config.default.json /etc/kyt/config.json", shell=True)
        subprocess.call("systemctl restart kyt", shell=True)

        await event.answer("✅ Config berhasil direset & service direstart!", alert=True)
    except Exception as e:
        await event.answer(f"❌ Gagal reset config: {e}", alert=True)
