from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("PANEL CREATE ACCOUNT","menu")],
        [Button.url("PRIVATE MESSAGE","https://t.me/newbie_store24"),
         Button.url("ORDER SCRIPT","https://whatsapp.nevpn.site")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        # Ambil data server
        ssh = subprocess.check_output("cat /etc/ssh/.ssh.db | grep '###' | wc -l", shell=True).decode("ascii")
        vms = subprocess.check_output("cat /etc/vmess/.vmess.db | grep '###' | wc -l", shell=True).decode("ascii")
        vls = subprocess.check_output("cat /etc/vless/.vless.db | grep '###' | wc -l", shell=True).decode("ascii")
        trj = subprocess.check_output("cat /etc/trojan/.trojan.db | grep '###' | wc -l", shell=True).decode("ascii")
        namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("ascii")
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii")
        city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii")

        msg = f"""```
╭━〔 🐾🕊️ PREMIUM PANEL 🕊️🐾 〕
┃
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {DOMAIN}
┃  • IP VPS         : {ipsaya.strip()}
┃  • OS             : {namaos.strip().replace('"','')}
┃  • CITY           : {city.strip()}
┃
┃━━━━━━━〔 Statistik Akun 〕
┃  📊 Ringkasan :
┃  ├  🚀 SSH OVPN    : {ssh.strip()}
┃  ├  🎭 XRAY VMESS  : {vms.strip()}
┃  ├  🗼 XRAY VLESS  : {vls.strip()}
┃  └  🎯 XRAY TROJAN : {trj.strip()}
┃
┃━━━━━━━〔 Informasi Penting 〕
┃  ⚠️ PERHATIAN :
┃  • Gunakan akun sesuai aturan
┃  • Backup config penting
┃  • Add-on hanya dari panel resmi
┃
┃━━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
```"""

        banner_link = "https://files.catbox.moe/599yde.jpg"  # ganti dengan link JPG kamu

        try:
            x = await event.edit(file=banner_link, caption=msg, buttons=inline)
            if not x:
                await event.reply(file=banner_link, caption=msg, buttons=inline)
        except:
            # fallback kalau edit gagal
            await event.reply(msg, buttons=inline)
