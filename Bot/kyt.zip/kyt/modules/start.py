from kyt import *
import subprocess
import asyncio
from telethon import events
from telethon.tl.custom import Button
from kyt.cfmenunew import *


# === START MENU TANPA ANIMASI ===
@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # === Ambil data server langsung tanpa animasi ===
    def count_lines(file_path):
        try:
            return subprocess.check_output(
                f'grep -c "###" {file_path}', shell=True
            ).decode().strip()
        except:
            return "0"

    ssh = count_lines('/etc/ssh/.ssh.db')
    vms = count_lines('/etc/vmess/.vmess.db')
    vls = count_lines('/etc/vless/.vless.db')
    trj = count_lines('/etc/trojan/.trojan.db')

    try:
        namaos = subprocess.check_output(
            "grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '\"'", 
            shell=True
        ).decode().strip()
    except:
        namaos = "Unknown OS"

    try:
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
    except:
        ipsaya = "0.0.0.0"

    try:
        city = subprocess.check_output("cat /etc/xray/city", shell=True).decode().strip()
    except:
        city = "Unknown"

    msg = f"""```
╭━〔 🐾🕊️ PREMIUM PANEL 🕊️🐾 〕
┃
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {DOMAIN}
┃  • IP VPS         : {ipsaya}
┃  • OS             : {namaos}
┃  • CITY           : {city}
┃
┃━━━━━━━〔 Statistik Akun 〕
┃  📊 Ringkasan :
┃  ├  🚀 SSH OVPN    : {ssh}
┃  ├  🎭 XRAY VMESS  : {vms}
┃  ├  🗼 XRAY VLESS  : {vls}
┃  └  🎯 XRAY TROJAN : {trj}
┃
┃━━━━━━━〔 Informasi Penting 〕
┃  ⚠️ PERHATIAN :
┃  • Gunakan akun sesuai aturan
┃  • Backup config penting
┃  • Add-on hanya dari panel resmi
┃
┃━━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
```"""

    inline = [
    [Button.inline("⚡ PANEL CREATE ACCOUNT ⚡", b"menu")],
    [Button.inline("🌩 CLOUDFLARE MANAGER 🌩", b"cfmenu")],
    [Button.inline("🧰 RESET CONFIG (Fresh Restart)", b"reset")],
    [Button.url("💬 PRIVATE MESSAGE", "https://t.me/Kjsrealfamily"),
     Button.url("📞 WHATSAPP ADMIN", "https://wa.me/6285943111681")]
]

    banner_url = "https://files.catbox.moe/evzql8.jpg"

    if isinstance(event, events.CallbackQuery.Event):
        await event.edit(msg, buttons=inline)
    else:
        try:
            await bot.send_file(
                event.chat_id,
                banner_url,
                caption=msg,
                buttons=inline
            )
        except:
            await event.reply(msg, buttons=inline)


# === RESET CONFIG HANDLER ===
@bot.on(events.CallbackQuery(data=b'reset'))
async def reset_config_handler(event):
    try:
        # Hapus config lama + ganti dengan default
        subprocess.call("rm -rf /etc/kyt/config.json", shell=True)
        subprocess.call("cp /etc/kyt/config.default.json /etc/kyt/config.json", shell=True)

        # Restart service
        subprocess.call("systemctl restart kyt", shell=True)

        await event.answer("✅ Config berhasil direset & service direstart!", alert=True)
    except Exception as e:
        await event.answer(f"❌ Gagal reset config: {e}", alert=True)
