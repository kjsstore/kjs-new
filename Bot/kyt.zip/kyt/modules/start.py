from kyt import *
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("PANEL CREATE ACCOUNT","menu")],
        [Button.url("PRIVATE MESSAGE","https://t.me/newbie_store24"),
         Button.url("ORDER SCRIPT","https://whatsapp.nevpn.site")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        # Jumlah akun
        ssh = subprocess.getoutput("grep -c '###' /etc/ssh/.ssh.db")
        vms = subprocess.getoutput("grep -c '###' /etc/vmess/.vmess.db")
        vls = subprocess.getoutput("grep -c '###' /etc/vless/.vless.db")
        trj = subprocess.getoutput("grep -c '###' /etc/trojan/.trojan.db")

        # Info sistem
        namaos = subprocess.getoutput("grep -w PRETTY_NAME /etc/os-release | head -n1 | cut -d= -f2- | tr -d '\"'")
        ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
        domain = subprocess.getoutput("cat /etc/xray/domain 2>/dev/null || echo '-'")
        city = subprocess.getoutput("cat /etc/xray/city 2>/dev/null || echo '-'")

        # Cek status service
        def status(service):
            return "✅" if subprocess.call(f"systemctl is-active --quiet {service}", shell=True) == 0 else "❌"

        st_ssh = status("ssh") if subprocess.call("systemctl list-unit-files | grep -q ssh", shell=True) == 0 else status("dropbear")
        st_xray = status("xray")
        st_nginx = status("nginx")
        st_haproxy = status("haproxy")

        msg = f"""```
╭━〔 🐾🕊️ PREMIUM PANEL 🕊️🐾 〕
┃
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {domain.strip()}
┃  • IP VPS         : {ipsaya.strip()}
┃  • OS             : {namaos.strip()}
┃  • CITY           : {city.strip()}
┃
┃━━━━━━〔 Statistik Akun 〕
┃  🚀 SSH OVPN    : {ssh}
┃  🎭 XRAY VMESS  : {vms}
┃  🗼 XRAY VLESS  : {vls}
┃  🎯 XRAY TROJAN : {trj}
┃
┃━━━━━━〔 Status Service 〕
┃  • SSH/Dropbear : {st_ssh}
┃  • XRAY         : {st_xray}
┃  • NGINX        : {st_nginx}
┃  • HAProxy      : {st_haproxy}
┃
┃━━━━━━〔 Informasi Penting 〕
┃  ⚠️ Gunakan akun sesuai aturan
┃  ⚠️ Backup config penting
┃  ⚠️ Add-on hanya dari panel resmi
┃
┃━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
```"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)