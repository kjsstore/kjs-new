from kyt import *
from telethon import events, Button
import subprocess
import asyncio

# === START MENU FULL CHAT BUBBLE TANPA TAG USER ===
@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
async def start(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        await event.reply("🚫 Akses Ditolak", buttons=Button.clear())
        return

    # --- Ambil data server ---
    ssh = subprocess.getoutput('cat /etc/ssh/.ssh.db | grep "###" | wc -l')
    vms = subprocess.getoutput('cat /etc/vmess/.vmess.db | grep "###" | wc -l')
    vls = subprocess.getoutput('cat /etc/vless/.vless.db | grep "###" | wc -l')
    trj = subprocess.getoutput('cat /etc/trojan/.trojan.db | grep "###" | wc -l')
    namaos = subprocess.getoutput("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | cut -d= -f2").replace('"','')
    ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    city = subprocess.getoutput("cat /etc/xray/city")

    # --- Pesan bubble utama ---
    msg = f"""
╭━〔 🐾🕊️ PREMIUM PANEL 🕊️🐾 〕
┃
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {DOMAIN}
┃  • IP VPS         : {ipsaya.strip()}
┃  • OS             : {namaos.strip()}
┃  • CITY           : {city.strip()}
┃
┃━━━━━━━〔 Statistik Akun 〕
┃  📊 Ringkasan :
┃  ├  🚀 SSH OVPN    : {ssh.strip()}
┃  ├  🎭 XRAY VMESS  : {vms.strip()}
┃  ├  🗼 XRAY VLESS  : {vls.strip()}
┃  └  🎯 XRAY TROJAN : {trj.strip()}
┃
┃━━━━━━━〔 Informasi Penting 〕
┃  ⚠️ Gunakan akun sesuai aturan.
┃  ⚠️ Backup config penting.
┃  ⚠️ Add-on hanya dari panel resmi.
┃
┃━━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
"""

    # === Semua tombol di dekat kolom chat ===
    keyboard = [
        ["⚡ CREATE ACCOUNT ⚡"],
        ["🌩 MENU CF 🌩", "🧰 REFRESH 🧰"],
        ["📊 STATISTIK AKUN", "💬 PRIVATE KJS"],
        ["📞 WHATSAPP KJS", "🛠️ BANTUAN ADMIN"],
        ["❌ TUTUP MENU"]
    ]

    # === Kirim pesan bubble utama ===
    await bot.send_message(
        event.chat_id,
        msg,
        buttons=Button.keyboard(keyboard, resize=True)
    

# === RESET CONFIG HANDLER ===
@bot.on(events.CallbackQuery(data=b'reset'))
async def reset_config_handler(event):
    try:
        subprocess.call("rm -rf /etc/kyt/config.json", shell=True)
        subprocess.call("cp /etc/kyt/config.default.json /etc/kyt/config.json", shell=True)
        subprocess.call("systemctl restart kyt", shell=True)

        await event.answer("✅ Config berhasil direset & service direstart!", alert=True)
    except Exception as e:
        await event.answer(f"❌ Gagal reset config: {e}", alert=True)
