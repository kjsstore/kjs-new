from kyt import *
import subprocess
import asyncio

# === START MENU ===
@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # === Animasi ASCII Loading (edit pesan, bukan numpuk) ===
    frames = [
        "```\n[■■□□□□□□□□□□] 10% Initializing...\n```",
        "```\n[■■■■□□□□□□□□] 30% Checking System...\n```",
        "```\n[■■■■■■□□□□□□] 50% Loading Modules...\n```",
        "```\n[■■■■■■■■□□□□] 70% Fetching Data...\n```",
        "```\n[■■■■■■■■■■■■] 100% Done!\n```"
    ]

    msg_loading = await event.respond(frames[0])
    for frame in frames[1:]:
        await asyncio.sleep(0.7)
        await msg_loading.edit(frame)

    await asyncio.sleep(0.8)
    await msg_loading.delete()  # hapus animasi setelah selesai

    # === Ambil data server ===
    ssh = subprocess.check_output('cat /etc/ssh/.ssh.db | grep "###" | wc -l', shell=True).decode()
    vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode()
    vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode()
    trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode()
    namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode()
    ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode()
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode()

    msg = f"""```
╭━〔 🐾🕊️ PREMIUM PANEL 🕊️🐾 〕
┃
┃  • Status Server  : ✅ Online
┃  • DOMAIN         : {DOMAIN}
┃  • IP VPS         : {ipsaya.strip()}
┃  • OS             : {namaos.strip().replace('"','')}
┃  • CITY           : {city.strip()}
┃
┃━━━━━━━〔 Statistik Akun 〕
┃  📊 Ringkasan :
┃  ├  🚀 SSH OVPN    : {ssh.strip()}
┃  ├  🎭 XRAY VMESS  : {vms.strip()}
┃  ├  🗼 XRAY VLESS  : {vls.strip()}
┃  └  🎯 XRAY TROJAN : {trj.strip()}
┃
┃━━━━━━━〔 Informasi Penting 〕
┃  ⚠️ PERHATIAN :
┃  • Gunakan akun sesuai aturan
┃  • Backup config penting
┃  • Add-on hanya dari panel resmi
┃
┃━━━━━━━〔 Admin 〕
┃  @KJS_STORE
╰━━━━━━━━━━━━━━━━━╯
```"""

    inline = [
        [Button.inline("PANEL CREATE ACCOUNT", "menu")],
        [Button.url("PRIVATE MESSAGE", "https://t.me/Kjsrealfamily"),
         Button.url("WHATSAPP ADMIN", "https://wa.me/6285943111681")],
        [Button.inline("🔄 REFRESH BOT", "refresh")]
    ]

    banner_url = "https://files.catbox.moe/evzql8.jpg"

    if isinstance(event, events.CallbackQuery.Event):
        await event.edit(msg, buttons=inline)
    else:
        try:
            await bot.send_file(
                event.chat_id,
                banner_url,
                caption=msg,
                buttons=inline
            )
        except:
            await event.reply(msg, buttons=inline)


# === FITUR REFRESH BOT ===
@bot.on(events.CallbackQuery(data=b'refresh'))
async def refresh_bot(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        await event.answer("Akses Ditolak", alert=True)
        return

    try:
        # restart semua service penting
        services = ["ssh", "dropbear", "stunnel5", "xray", "cron"]
        for svc in services:
            subprocess.call(f"systemctl restart {svc}", shell=True)

        await event.edit("✅ Semua service berhasil direfresh & bot kembali normal.")
    except Exception as e:
        await event.edit(f"⚠️ Gagal refresh service:\n{e}")
