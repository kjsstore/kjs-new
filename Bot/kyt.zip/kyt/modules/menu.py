from kyt import *
import subprocess
import os

USER_FILE = "user_ids.txt"
ADMIN_IDS = []  # Akan diisi otomatis saat bot start

# ==================== Setup Admin ====================
async def set_admin():
    me = await bot.get_me()
    ADMIN_IDS.append(me.id)

bot.loop.create_task(set_admin())

# ==================== Utility ====================
def get_user_ids():
    if not os.path.exists(USER_FILE):
        return []
    with open(USER_FILE, "r") as f:
        return [line.strip() for line in f.readlines() if line.strip()]

def add_user_id(user_id):
    user_ids = get_user_ids()
    if str(user_id) not in user_ids:
        with open(USER_FILE, "a") as f:
            f.write(f"{user_id}\n")
        return True
    return False

def del_user_id(user_id):
    user_ids = get_user_ids()
    if str(user_id) in user_ids:
        user_ids.remove(str(user_id))
        with open(USER_FILE, "w") as f:
            for uid in user_ids:
                f.write(f"{uid}\n")
        return True
    return False

def valid(user_id):
    """Admin selalu bisa akses, user lain harus ada di file"""
    if int(user_id) in ADMIN_IDS:
        return True
    return str(user_id) in get_user_ids()

# ==================== Command Admin ====================
@bot.on(events.NewMessage(pattern=r"(?:.addid|/addid) (\d+)$"))
async def handler_addid(event):
    sender = await event.get_sender()
    if sender.id not in ADMIN_IDS:
        return await event.reply("❌ Hanya admin yang bisa nambahin user ID.")
    user_id = event.pattern_match.group(1)
    if add_user_id(user_id):
        await event.reply(f"✅ ID `{user_id}` berhasil ditambahkan ke akses menu.")
    else:
        await event.reply(f"ℹ️ ID `{user_id}` sudah ada di daftar.")

@bot.on(events.NewMessage(pattern=r"(?:.delid|/delid) (\d+)$"))
async def handler_delid(event):
    sender = await event.get_sender()
    if sender.id not in ADMIN_IDS:
        return await event.reply("❌ Hanya admin yang bisa menghapus user ID.")
    user_id = event.pattern_match.group(1)
    if del_user_id(user_id):
        await event.reply(f"✅ ID `{user_id}` berhasil dihapus dari daftar akses.")
    else:
        await event.reply(f"ℹ️ ID `{user_id}` tidak ditemukan di daftar.")

@bot.on(events.NewMessage(pattern=r"(?:.listid|/listid)$"))
async def handler_listid(event):
    sender = await event.get_sender()
    if sender.id not in ADMIN_IDS:
        return await event.reply("❌ Hanya admin yang bisa melihat daftar user ID.")
    user_ids = get_user_ids()
    if not user_ids:
        await event.reply("ℹ️ Tidak ada user ID yang terdaftar.")
    else:
        msg = "📋 **Daftar User ID yang Memiliki Akses:**\n\n"
        msg += "\n".join(f"• `{uid}`" for uid in user_ids)
        await event.reply(msg)

# ==================== Menu Utama ====================
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" LIST USER ID ", "listid"),
         Button.inline(" ‹ Back Menu › ","start")]
    ]

    sender = await event.get_sender()
    if not valid(sender.id):
        try:
            return await event.answer("🚫 Akses Ditolak", alert=True)
        except:
            return await event.reply("🚫 Akses Ditolak")

    # Statistik server, tetap format lama
    ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii")
    vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii")
    vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii")
    trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii")
    namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("ascii")
    ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii")
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii")

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🐾🕊️ ADMIN PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━
**» OS       :** `{namaos.strip().replace('"','')}`
**» CITY     :** `{city.strip()}`
**» DOMAIN   :** `{DOMAIN}`
**» IP VPS   :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀 SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭 XRAY VMESS  :** `{vms.strip()}` __account__
**» 🗼 XRAY VLESS  :** `{vls.strip()}` __account__
**» 🎯 XRAY TROJAN :** `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━
"""
    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)

# ==================== Callback Tombol ====================
@bot.on(events.CallbackQuery)
async def callback_handler(event):
    data = event.data.decode("utf-8")
    sender = await event.get_sender()
    
    if not valid(sender.id):
        return await event.answer("🚫 Akses Ditolak", alert=True)

    if data == "listid":
        user_ids = get_user_ids()
        if not user_ids:
            await event.answer("ℹ️ Tidak ada user ID yang terdaftar.", alert=True)
        else:
            msg = "📋 **Daftar User ID yang Memiliki Akses:**\n\n"
            msg += "\n".join(f"• `{uid}`" for uid in user_ids)
            await event.answer(msg, alert=True)
