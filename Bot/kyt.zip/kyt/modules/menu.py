from kyt import *
import subprocess

# === MENU UTAMA ===
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Start › ","start")]  # <= balik ke start
    ]

    # Ambil statistik server
    ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode()
    vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode()
    vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode()
    trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode()
    namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode()
    ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode()
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode()

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🐾🕊️ PUBLIC PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━
**» OS       :** `{namaos.strip().replace('"','')}`
**» CITY     :** `{city.strip()}`
**» DOMAIN   :** `{DOMAIN}`
**» IP VPS   :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀 SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭 XRAY VMESS  :** `{vms.strip()}` __account__
**» 🗼 XRAY VLESS  :** `{vls.strip()}` __account__
**» 🎯 XRAY TROJAN :** `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await event.edit(msg, buttons=inline)


# === HANDLER UNTUK SETIAP SUBMENU ===
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_menu(event):
    buttons = [[Button.inline(" ‹ Back Menu › ", "menu")]]
    await event.edit("🚀 **SSH / OVPN MANAGER** 🚀", buttons=buttons)


@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess_menu(event):
    buttons = [[Button.inline(" ‹ Back Menu › ", "menu")]]
    await event.edit("🎭 **VMESS MANAGER** 🎭", buttons=buttons)


@bot.on(events.CallbackQuery(data=b'vless'))
async def vless_menu(event):
    buttons = [[Button.inline(" ‹ Back Menu › ", "menu")]]
    await event.edit("🗼 **VLESS MANAGER** 🗼", buttons=buttons)


@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan_menu(event):
    buttons = [[Button.inline(" ‹ Back Menu › ", "menu")]]
    await event.edit("🎯 **TROJAN MANAGER** 🎯", buttons=buttons)


@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def ss_menu(event):
    buttons = [[Button.inline(" ‹ Back Menu › ", "menu")]]
    await event.edit("⚡ **SHADOWSOCKS MANAGER** ⚡", buttons=buttons)


@bot.on(events.CallbackQuery(data=b'info'))
async def info_menu(event):
    buttons = [[Button.inline(" ‹ Back Menu › ", "menu")]]
    await event.edit("📊 **CHECK VPS INFO** 📊", buttons=buttons)


@bot.on(events.CallbackQuery(data=b'setting'))
async def setting_menu(event):
    buttons = [[Button.inline(" ‹ Back Menu › ", "menu")]]
    await event.edit("⚙️ **OTHER SETTING** ⚙️", buttons=buttons)
