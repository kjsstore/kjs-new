import subprocess
from telethon import events, Button
from kyt import bot, DOMAIN, valid  # pastikan valid() ada di kyt.py
from __main__ import is_allowed, ADMIN_ID  # ambil fungsi whitelist & admin_id

@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id

    # Cek akses whitelist
    if user_id != ADMIN_ID and not is_allowed(user_id):
        try:
            await event.answer("🚫 Akses Ditolak! Hubungi admin.", alert=True)
        except:
            await event.reply("🚫 Akses Ditolak! Hubungi admin.")
        return

    # Inline tombol menu
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]

    # Fungsi helper ambil data
    def run_cmd(cmd):
        try:
            return subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
        except:
            return "-"

    # Ambil data akun/server
    ssh = run_cmd('cat /etc/passwd | grep "home" | grep "false" | wc -l')
    vms = run_cmd('cat /etc/vmess/.vmess.db | grep "###" | wc -l')
    vls = run_cmd('cat /etc/vless/.vless.db | grep "###" | wc -l')
    trj = run_cmd('cat /etc/trojan/.trojan.db | grep "###" | wc -l')
    namaos = run_cmd('grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d \'"\'')
    city = run_cmd('cat /etc/xray/city')

    # Admin bisa lihat IP & DOMAIN
    if user_id == ADMIN_ID:
        ipsaya = run_cmd('curl -s ipv4.icanhazip.com')
        domain_display = DOMAIN
    else:
        ipsaya = "-"
        domain_display = "-"

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS     :** `{namaos}`
**» CITY   :** `{city}`
**» DOMAIN :** `{domain_display}`
**» IP VPS :** `{ipsaya}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh}` __account__
**» 🎭XRAY VMESS  :** `{vms}` __account__
**» 🗼XRAY VLESS  :** `{vls}` __account__
**» 🎯XRAY TROJAN :** `{trj}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""

    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)