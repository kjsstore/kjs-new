import subprocess
from telethon import events, Button
from kyt import bot, DOMAIN, valid  # pastikan valid() ada di kyt.py

@bot.on(events.NewMessage(pattern=r"(?:\.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Inline tombol
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]

    val = valid(user_id)
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # Ambil data akun/server
    def run_cmd(cmd):
        try:
            return subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
        except:
            return "-"

    ssh = run_cmd('cat /etc/passwd | grep "home" | grep "false" | wc -l')
    vms = run_cmd('cat /etc/vmess/.vmess.db | grep "###" | wc -l')
    vls = run_cmd('cat /etc/vless/.vless.db | grep "###" | wc -l')
    trj = run_cmd('cat /etc/trojan/.trojan.db | grep "###" | wc -l')
    namaos = run_cmd('grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d \'"\'')
    ipsaya = run_cmd('curl -s ipv4.icanhazip.com')
    city = run_cmd('cat /etc/xray/city')

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ ADMIN PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS     :** `{namaos}`
**» CITY   :** `{city}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh}` __account__
**» 🎭XRAY VMESS  :** `{vms}` __account__
**» 🗼XRAY VLESS  :** `{vls}` __account__
**» 🎯XRAY TROJAN :** `{trj}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""

    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)