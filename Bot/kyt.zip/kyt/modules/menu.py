from kyt import *
import subprocess
from telethon import events, Button

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    firstname = sender.first_name or "Tidak ada"
    username = f"@{sender.username}" if sender.username else "Tidak ada"
    

    # =========================
    # Cek whitelist
    # =========================
    if not is_allowed(user_id):
        try:
            await event.answer("🚫 Akses Ditolak. Hubungi admin.", alert=True)
        except:
            await event.reply("🚫 Akses Ditolak. Hubungi admin.")
        return

    # =========================
    # Helper menjalankan shell command
    # =========================
    def run_cmd(cmd):
        try:
            return subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
        except:
            return "N/A"

    # =========================
    # Hitung jumlah akun
    # =========================
    ssh = run_cmd('cat /etc/passwd | grep "home" | grep "false" | wc -l')
    vms = run_cmd('cat /etc/vmess/.vmess.db | grep "###" | wc -l')
    vls = run_cmd('cat /etc/vless/.vless.db | grep "###" | wc -l')
    trj = run_cmd('cat /etc/trojan/.trojan.db | grep "###" | wc -l')

    # =========================
    # Info server
    # =========================
    namaos = run_cmd('cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | cut -d "=" -f2 | tr -d \'"\'')
    ipsaya = run_cmd('curl -s ipv4.icanhazip.com')
    try:
        with open("/etc/xray/city", "r") as f:
            city = f.read().strip()
    except:
        city = "Unknown"

    # =========================
    # Tombol panel lengkap untuk semua user di whitelist
    # =========================
    inline = [
        [Button.inline("SSH OVPN MANAGER","ssh")],
        [Button.inline("VMESS MANAGER","vmess"), Button.inline("VLESS MANAGER","vless")],
        [Button.inline("TROJAN MANAGER","trojan"), Button.inline("SHDWSK MANAGER","shadowsocks")],
        [Button.inline("CHECK VPS INFO","info"), Button.inline("OTHER SETTING","setting")],
        [Button.inline("‹ Back Menu ›","start")]
    ]

    # =========================
    # Pesan panel lengkap
    # =========================
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS     :** `{namaos}`
**» CITY   :** `{city}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya}`
**» Total Account Created:** 

**» 🚀 SSH OVPN    :** `{ssh}` __account__
**» 🎭 XRAY VMESS  :** `{vms}` __account__
**» 🗼 XRAY VLESS  :** `{vls}` __account__
**» 🎯 XRAY TROJAN :** `{trj}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await bot.send_file(event.chat_id, banner)
    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)