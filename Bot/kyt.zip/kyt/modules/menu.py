from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id

    # cek whitelist
    if not is_allowed(user_id):
        try:
            await event.answer("🚫 Akses Ditolak! Kamu belum terdaftar di whitelist.", alert=True)
        except:
            await event.reply("🚫 Akses Ditolak! Kamu belum terdaftar di whitelist.")
        return

    # tombol menu
    inline = [
        [Button.inline(" SSH OVPN MANAGER ", "ssh")],
        [Button.inline(" VMESS MANAGER ", "vmess"),
         Button.inline(" VLESS MANAGER ", "vless")],
        [Button.inline(" TROJAN MANAGER ", "trojan"),
         Button.inline(" SHDWSK MANAGER ", "shadowsocks")],
        [Button.inline(" CHECK VPS INFO ", "info"),
         Button.inline(" OTHER SETTING ", "setting")],
        [Button.inline(" ‹ Back Menu › ", "start")]
    ]

    # data akun & server
    sh = "cat /etc/passwd | grep 'home' | grep 'false' | wc -l"
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")

    vm = "cat /etc/vmess/.vmess.db | grep '###' | wc -l"
    vms = subprocess.check_output(vm, shell=True).decode("ascii")

    vl = "cat /etc/vless/.vless.db | grep '###' | wc -l"
    vls = subprocess.check_output(vl, shell=True).decode("ascii")

    tr = "cat /etc/trojan/.trojan.db | grep '###' | wc -l"
    trj = subprocess.check_output(tr, shell=True).decode("ascii")

    sdss = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")

    ipvps = "curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

    citsy = "cat /etc/xray/city"
    city = subprocess.check_output(citsy, shell=True).decode("ascii")
    
    BANNER_URL = "https://files.catbox.moe/vl2fdm.jpeg"  # ganti dengan link JPG kamu
    # bedakan pesan admin dan user
    if user_id == ADMIN_ID:
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**👑 OWNER PANEL**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» ID      :** `{user_id}`
**» NAME    :** `{sender.first_name}`
**» USERNAME:** @{sender.username if sender.username else "-"}
━━━━━━━━━━━━━━━━━━━━━━━ 
**🖥 SERVER INFORMATION**
• OS      : `{namaos.strip().replace('"','')}`
• CITY    : `{city.strip()}`
• DOMAIN  : `{DOMAIN}`
• IP VPS  : `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━━━━━ 
**📊 JUMLAH AKUN**
• 🚀SSH OVPN    : `{ssh.strip()}`
• 🎭XRAY VMESS  : `{vms.strip()}`
• 🗼XRAY VLESS  : `{vls.strip()}`
• 🎯XRAY TROJAN : `{trj.strip()}`
━━━━━━━━━━━━━━━━━━━━━━━ 
🚀 Powered by **YourBrand™**
"""
    else:
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**👤 USER PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━ 
✅ Kamu sudah diizinkan oleh admin untuk menggunakan panel ini.  

**📊 JUMLAH AKUN**
• 🚀SSH OVPN    : `{ssh.strip()}`
• 🎭XRAY VMESS  : `{vms.strip()}`
• 🗼XRAY VLESS  : `{vls.strip()}`
• 🎯XRAY TROJAN : `{trj.strip()}`

📌 Gunakan akun dengan bijak, dilarang menyalahgunakan!
━━━━━━━━━━━━━━━━━━━━━━━ 
"""

    # hapus command biar rapi
    await event.delete()

    # kirim banner dulu
    await event.respond(file=BANNER_URL)

    # kirim caption + tombol (tombol bisa diklik!)
    await event.respond(msg, buttons=inline)