from kyt import *

BANNER_URL = "https://files.catbox.moe/dgxwad.png"  # ganti dengan link JPG kamu

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id

    # cek whitelist
    if not is_allowed(user_id):
        try:
            await event.answer("🚫 Akses Ditolak! Kamu belum terdaftar di whitelist.", alert=True)
        except:
            await event.reply("🚫 Akses Ditolak! Kamu belum terdaftar di whitelist.")
        return

    # tombol menu
    inline = [
        [Button.inline(" SSH OVPN MANAGER ", "ssh")],
        [Button.inline(" VMESS MANAGER ", "vmess"),
         Button.inline(" VLESS MANAGER ", "vless")],
        [Button.inline(" TROJAN MANAGER ", "trojan"),
         Button.inline(" SHDWSK MANAGER ", "shadowsocks")],
        [Button.inline(" CHECK VPS INFO ", "info"),
         Button.inline(" OTHER SETTING ", "setting")],
        [Button.inline(" ‹ Back Menu › ", "start")]
    ]

    # data akun & server
    sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")

    vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")

    vl = f'cat /etc/vless/.vless.db | grep "###" | wc -l'
    vls = subprocess.check_output(vl, shell=True).decode("ascii")

    tr = f'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
    trj = subprocess.check_output(tr, shell=True).decode("ascii")

    sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")

    ipvps = f"curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

    citsy = f"cat /etc/xray/city"
    city = subprocess.check_output(citsy, shell=True).decode("ascii")

    # bedakan pesan admin dan user
    if user_id == ADMIN_ID:
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ ADMIN PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS      :** `{namaos.strip().replace('"','')}`
**» CITY    :** `{city.strip()}`
**» DOMAIN  :** `{DOMAIN}`
**» IP VPS  :** `{ipsaya.strip()}`

**📊 Total Account Created:** 
• 🚀SSH OVPN    : `{ssh.strip()}` akun
• 🎭XRAY VMESS  : `{vms.strip()}` akun
• 🗼XRAY VLESS  : `{vls.strip()}` akun
• 🎯XRAY TROJAN : `{trj.strip()}` akun
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    else:
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**👤 USER PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━ 
✅ Kamu sudah diizinkan oleh admin untuk menggunakan panel ini.  
Silakan pilih menu di bawah untuk membuat akun.  

**📊 Total Account Created:** 
• 🚀SSH OVPN    : `{ssh.strip()}` akun
• 🎭XRAY VMESS  : `{vms.strip()}` akun
• 🗼XRAY VLESS  : `{vls.strip()}` akun
• 🎯XRAY TROJAN : `{trj.strip()}` akun

📌 Gunakan akun dengan bijak, dilarang menyalahgunakan!
━━━━━━━━━━━━━━━━━━━━━━━ 
"""

    # kirim banner + caption + tombol
    try:
        await bot.send_file(
            event.chat_id,
            file=BANNER_URL,
            caption=msg,
            buttons=inline
        )
        await event.delete()  # hapus pesan /menu biar rapi
    except:
        # fallback kalau banner gagal
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)