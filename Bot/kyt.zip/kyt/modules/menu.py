import subprocess
from telethon import events, Button
from kyt import bot, is_allowed, DOMAIN

BANNER_URL = "https://files.catbox.moe/vl2fdm.jpeg"

@bot.on(events.NewMessage(pattern=r"(?:\.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id

    if not is_allowed(user_id):
        try:
            await event.answer("🚫 Akses ditolak!", alert=True)
        except:
            await event.reply("🚫 Akses ditolak!")
        return

    # Inline buttons sama untuk admin & user
    inline = [
        [Button.inline("🔑 SSH OVPN MANAGER", b"ssh")],
        [Button.inline("⚡ VMESS MANAGER", b"vmess"),
         Button.inline("✨ VLESS MANAGER", b"vless")],
        [Button.inline("🔒 TROJAN MANAGER", b"trojan"),
         Button.inline("🌀 SHADOWSOCKS MANAGER", b"shadowsocks")],
        [Button.inline("💻 CHECK VPS INFO", b"info"),
         Button.inline("⚙️ OTHER SETTING", b"setting")],
        [Button.inline("⬅️ Back Menu", b"start")]
    ]

    # Data akun
    def count_lines(filepath):
        try:
            with open(filepath, "r") as f:
                return sum(1 for line in f if "###" in line)
        except FileNotFoundError:
            return 0

    ssh = count_lines("/etc/ssh/.ssh.db")
    vms = count_lines("/etc/vmess/.vmess.db")
    vls = count_lines("/etc/vless/.vless.db")
    trj = count_lines("/etc/trojan/.trojan.db")

    # Data server
    import platform, socket, requests
    namaos = platform.platform()
    try:
        with open("/etc/xray/city", "r") as f:
            city = f.read().strip()
    except FileNotFoundError:
        city = "Unknown"

    try:
        ipsaya = requests.get("https://ipv4.icanhazip.com").text.strip()
    except Exception:
        ipsaya = socket.gethostbyname(socket.gethostname())

    # ===== Pesan untuk admin =====
    if user_id == 7559356014:  # ADMIN_ID
        msg = f"""
╔════════════════════════╗
       👑 **ADMIN PANEL**
╚════════════════════════╝

💻 **SERVER INFO**
• OS       : `{namaos.strip()}`
• CITY     : `{city.strip()}`
• DOMAIN   : `{DOMAIN}`
• IP VPS   : `{ipsaya.strip()}`

📊 **TOTAL ACCOUNT CREATED**
• 🚀 SSH       : {ssh}
• ⚡ VMESS     : {vms}
• ✨ VLESS     : {vls}
• 🔒 TROJAN    : {trj}

━━━━━━━━━━━━━━━━━━━━━━━
🚀 Powered by **KJS-STORE™**
━━━━━━━━━━━━━━━━━━━━━━━
"""
    # ===== Pesan untuk whitelist user =====
    else:
        msg = f"""
╔════════════════════════╗
       👤 **USER PANEL**
╚════════════════════════╝

💻 **SERVER INFO**
• OS       : `{namaos.strip()}`
• CITY     : `{city.strip()}`

📊 **TOTAL ACCOUNT CREATED**
• 🚀 SSH       : {ssh}
• ⚡ VMESS     : {vms}
• ✨ VLESS     : {vls}
• 🔒 TROJAN    : {trj}

━━━━━━━━━━━━━━━━━━━━━━━
🚀 Powered by **KJS-STORE™**
━━━━━━━━━━━━━━━━━━━━━━━
"""

    # Kirim banner + pesan
    await bot.send_file(event.chat_id, BANNER_URL)
    await event.respond(msg, buttons=inline, link_preview=False)