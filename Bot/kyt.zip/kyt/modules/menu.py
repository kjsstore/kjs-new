from kyt import *
import subprocess
from telethon import events, Button
from main import is_allowed, DOMAIN, ADMIN_ID  # pastikan import dari file utama

BANNER = "https://files.catbox.moe/vl2fdm.jpeg"  # ganti banner sesuai kebutuhan

@bot.on(events.NewMessage(pattern=r"(?:\.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # cek whitelist
    if not is_allowed(user_id):
        try:
            await event.answer("🚫 Akses ditolak! Kamu belum ada di whitelist.", alert=True)
        except:
            await event.reply("🚫 Akses ditolak! Kamu belum ada di whitelist.")
        return

    # tombol menu
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]

    # ambil data akun
    try:
        ssh = subprocess.check_output(
            'cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True
        ).decode().strip()
        vms = subprocess.check_output(
            'cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True
        ).decode().strip()
        vls = subprocess.check_output(
            'cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True
        ).decode().strip()
        trj = subprocess.check_output(
            'cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True
        ).decode().strip()

        namaos = subprocess.check_output(
            "grep -w PRETTY_NAME /etc/os-release | cut -d= -f2", shell=True
        ).decode().strip().replace('"', '')
        ipsaya = subprocess.check_output(
            "curl -s ipv4.icanhazip.com", shell=True
        ).decode().strip()
        city = subprocess.check_output(
            "cat /etc/xray/city", shell=True
        ).decode().strip()
    except Exception as e:
        return await event.reply(f"⚠️ Error ambil data server:\n`{str(e)}`")

    # =========================
    # OWNER (ADMIN)
    # =========================
    if sender.id == ADMIN_ID:
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**👑 ADMIN PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS     :** `{namaos}`
**» CITY   :** `{city}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh}` account
**» 🎭XRAY VMESS  :** `{vms}` account
**» 🗼XRAY VLESS  :** `{vls}` account
**» 🎯XRAY TROJAN :** `{trj}` account
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    # =========================
    # USER BIASA
    # =========================
    else:
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**👤 USER PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh}` account
**» 🎭XRAY VMESS  :** `{vms}` account
**» 🗼XRAY VLESS  :** `{vls}` account
**» 🎯XRAY TROJAN :** `{trj}` account

⚠️ Gunakan akun dengan bijak.
━━━━━━━━━━━━━━━━━━━━━━━ 
"""

    # kirim banner + pesan menu
    await bot.send_file(event.chat_id, BANNER)
    try:
        await event.respond(msg, buttons=inline, link_preview=False)
    except:
        await event.reply(msg, buttons=inline, link_preview=False)