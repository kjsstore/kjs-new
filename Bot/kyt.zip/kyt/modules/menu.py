from kyt import *
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]

    # Ambil statistik server
    ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii")
    vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii")
    vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii")
    trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii")
    namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("ascii")
    ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii")
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii")

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🐾🕊️ PUBLIC PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━
**» OS       :** `{namaos.strip().replace('"','')}`
**» CITY     :** `{city.strip()}`
**» DOMAIN   :** `{DOMAIN}`
**» IP VPS   :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀 SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭 XRAY VMESS  :** `{vms.strip()}` __account__
**» 🗼 XRAY VLESS  :** `{vls.strip()}` __account__
**» 🎯 XRAY TROJAN :** `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━
"""
    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)