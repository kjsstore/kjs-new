import subprocess
from telethon import events, Button
from kyt import *   # bot harus sudah diimport dari sini
from main import is_allowed, ADMIN_ID, DOMAIN  # import whitelist check & config

@bot.on(events.NewMessage(pattern=r"(?:\.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id

    # cek whitelist
    if not is_allowed(user_id):
        try:
            await event.answer("🚫 Akses ditolak!", alert=True)
        except:
            await event.reply("🚫 Akses ditolak!")
        return

    # tombol menu
    inline = [
        [Button.inline("🔑 SSH OVPN MANAGER", b"ssh")],
        [Button.inline("⚡ VMESS MANAGER", b"vmess"),
         Button.inline("✨ VLESS MANAGER", b"vless")],
        [Button.inline("🔒 TROJAN MANAGER", b"trojan"),
         Button.inline("🌀 SHADOWSOCKS MANAGER", b"shadowsocks")],
        [Button.inline("💻 CHECK VPS INFO", b"info"),
         Button.inline("⚙️ OTHER SETTING", b"setting")],
        [Button.inline("⬅️ Back Menu", b"start")]
    ]

    # ambil data server
    ssh = subprocess.getoutput('cat /etc/passwd | grep "home" | grep "false" | wc -l')
    vms = subprocess.getoutput('cat /etc/vmess/.vmess.db | grep "###" | wc -l')
    vls = subprocess.getoutput('cat /etc/vless/.vless.db | grep "###" | wc -l')
    trj = subprocess.getoutput('cat /etc/trojan/.trojan.db | grep "###" | wc -l')
    namaos = subprocess.getoutput("grep -w PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '\"'")
    ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    city = subprocess.getoutput("cat /etc/xray/city")

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
👑 **ADMIN PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━ 

💻 **SERVER INFO**  
• OS       : `{namaos.strip()}`  
• CITY     : `{city.strip()}`  
• DOMAIN   : `{DOMAIN}`  
• IP VPS   : `{ipsaya.strip()}`  

📊 **TOTAL ACCOUNT CREATED**  
• 🚀 SSH OVPN   : `{ssh.strip()}` account  
• ⚡ XRAY VMESS : `{vms.strip()}` account  
• ✨ XRAY VLESS : `{vls.strip()}` account  
• 🔒 XRAY TROJAN: `{trj.strip()}` account  

━━━━━━━━━━━━━━━━━━━━━━━  
🚀 Powered by **KJS-STORE™**  
━━━━━━━━━━━━━━━━━━━━━━━
"""
    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)