from kyt import *
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id

    # cek whitelist
    if not is_allowed(user_id):
        try:
            await event.answer("🚫 Akses Ditolak. Hubungi admin.", alert=True)
        except:
            await event.reply("🚫 Akses Ditolak. Hubungi admin.")
        return

    # tombol menu
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]

    # ambil data server
    try:
        ssh = subprocess.getoutput("cat /etc/passwd | grep 'home' | grep 'false' | wc -l")
        vms = subprocess.getoutput("cat /etc/vmess/.vmess.db | grep '###' | wc -l")
        vls = subprocess.getoutput("cat /etc/vless/.vless.db | grep '###' | wc -l")
        trj = subprocess.getoutput("cat /etc/trojan/.trojan.db | grep '###' | wc -l")
        namaos = subprocess.getoutput("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").replace('"','')
        ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
        city = subprocess.getoutput("cat /etc/xray/city")
    except:
        ssh = vms = vls = trj = "0"
        namaos = city = ipsaya = "Unknown"

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS       :** `{namaos}`
**» CITY     :** `{city}`
**» DOMAIN   :** `{DOMAIN}`
**» IP VPS   :** `{ipsaya}`

**» Total Account Created:** 
**» 🚀SSH OVPN    :** `{ssh}` __account__
**» 🎭XRAY VMESS  :** `{vms}` __account__
**» 🗼XRAY VLESS  :** `{vls}` __account__
**» 🎯XRAY TROJAN :** `{trj}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""

    # edit pesan lama (callback) atau reply pesan baru
    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)