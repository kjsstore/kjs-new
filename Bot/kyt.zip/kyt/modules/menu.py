from kyt import *
import subprocess
import platform
import requests
import socket
from telethon import events, Button

# cek whitelist
def is_allowed(user_id):
    try:
        with open("whitelist.txt", "r") as f:
            ids = f.read().splitlines()
        return str(user_id) in ids
    except FileNotFoundError:
        return False

# hitung akun
def count_lines(filepath):
    try:
        with open(filepath, "r") as f:
            return sum(1 for line in f if "###" in line)
    except FileNotFoundError:
        return 0

# menu utama
@bot.on(events.NewMessage(pattern=r"(?:\.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id

    # cek whitelist
    if not is_allowed(user_id):
        msg = "🚫 Akses Ditolak!\nGunakan /reqakses untuk minta izin."
        try:
            if isinstance(event, events.CallbackQuery.Event):
                await event.answer(msg, alert=True)
            else:
                await event.reply(msg)
        except:
            await event.reply(msg)
        return

    # info user login
    firstname = sender.first_name or "Tidak ada"
    username = f"@{sender.username}" if sender.username else "Tidak ada"
    status_login = f"{firstname} ({username})"

    # hitung akun dari db
    ssh = count_lines("/etc/ssh/.ssh.db")
    vms = count_lines("/etc/vmess/.vmess.db")
    vls = count_lines("/etc/vless/.vless.db")
    trj = count_lines("/etc/trojan/.trojan.db")
    total_created = ssh + vms + vls + trj

    # info server
    namaos = platform.platform()
    try:
        with open("/etc/xray/city", "r") as f:
            city = f.read().strip()
    except FileNotFoundError:
        city = "Unknown"

    try:
        ipsaya = requests.get("https://ipv4.icanhazip.com", timeout=5).text.strip()
    except:
        ipsaya = socket.gethostbyname(socket.gethostname())

    try:
        DOMAIN
    except NameError:
        DOMAIN = "Belum Diset"

    # tombol menu
    inline = [
        [Button.inline("🚀 SSH OVPN MANAGER", b"ssh")],
        [Button.inline("🎭 VMESS MANAGER", b"vmess"), Button.inline("🗼 VLESS MANAGER", b"vless")],
        [Button.inline("🎯 TROJAN MANAGER", b"trojan"), Button.inline("🌐 SHDWSK MANAGER", b"shadowsocks")],
        [Button.inline("📡 CHECK VPS INFO", b"info"), Button.inline("⚙️ OTHER SETTING", b"setting")],
        [Button.inline("‹ Back Menu ›", b"start")]
    ]

    # pesan panel
    msg = f"""
╭━━━〔 𝗕𝗢𝗧 𝗔𝗨𝗧𝗢 𝗢𝗥𝗗𝗘𝗥 〕
┃
┃  • User        : ✅ {status_login}
┃
┃━━━━━━━〔 Server Info 〕
┃  🖥️ OS         : {namaos.strip()}
┃  🌍 CITY       : {city.strip()}
┃  🌐 DOMAIN     : {DOMAIN}
┃  📡 IP VPS     : {ipsaya.strip()}
┃
┃━━━━━━━〔 Total Account Created 〕
┃  🔑 SSH OVPN    : {ssh} akun
┃  ⚡ XRAY VMESS  : {vms} akun
┃  ✨ XRAY VLESS  : {vls} akun
┃  🔒 XRAY TROJAN : {trj} akun
┃  🌐 TOTAL       : {total_created} akun
┃
┃━━━━━━━〔 Admin 〕
┃  @AutoFtBot69
╰━━━━━━━━━━━━━━━━━━━━━━━━╯
"""

    try:
        await event.edit(msg, buttons=inline, link_preview=False)
    except:
        await event.reply(msg, buttons=inline, link_preview=False)