import os
import sys
import re
import time
import math
import json
import base64
import random
import sqlite3
import logging
import requests
import subprocess
import datetime as DT
from telethon import TelegramClient

# Logging
logging.basicConfig(level=logging.INFO)

# Waktu mulai (uptime)
uptime = DT.datetime.now()

# Load variabel (BOT_TOKEN, ADMIN) dari var.txt
exec(open("/usr/bin/kyt/var.txt", "r").read())

# Inisialisasi bot
bot = TelegramClient(
    "kyt_session",  # nama session
    "6",            # api_id (dummy, isi sesuai lo)
    "eb06d4abfb49dc3eeb1aeb98ae0f581e"  # api_hash
).start(bot_token=BOT_TOKEN)

DB_PATH = "/usr/bin/kyt/database.db"

# Cek database admin
if not os.path.exists(DB_PATH):
    db = sqlite3.connect(DB_PATH)
    c = db.cursor()
    c.execute("CREATE TABLE admin (user_id TEXT)")
    c.execute("INSERT INTO admin (user_id) VALUES (?)", (ADMIN,))
    db.commit()
    db.close()

# Helper: koneksi DB
def get_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db

# Helper: cek user valid
def valid(user_id: str) -> bool:
    db = get_db()
    rows = db.execute("SELECT user_id FROM admin").fetchall()
    db.close()
    return user_id in [row[0] for row in rows]

# Helper: konversi ukuran file
def convert_size(size_bytes: int) -> str:
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"